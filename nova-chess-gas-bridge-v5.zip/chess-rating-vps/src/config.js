const path = require('node:path');

function integerEnv(name, fallback, { min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER } = {}) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const value = Number.parseInt(raw, 10);
  if (!Number.isFinite(value) || value < min || value > max) return fallback;
  return value;
}

const config = Object.freeze({
  host: process.env.HOST || '0.0.0.0',
  port: integerEnv('PORT', 6555, { min: 1, max: 65535 }),
  nodeEnv: process.env.NODE_ENV || 'development',
  dataDir: path.resolve(process.env.DATA_DIR || path.join(process.cwd(), 'data')),
  trustProxy: integerEnv('TRUST_PROXY', 0, { min: 0, max: 10 }),
  cookieSecure: process.env.COOKIE_SECURE === 'true',
  sessionDays: integerEnv('SESSION_DAYS', 30, { min: 1, max: 365 }),
  initialRating: integerEnv('INITIAL_RATING', 100, { min: 0, max: 10000 }),
  eloK: integerEnv('ELO_K', 32, { min: 1, max: 200 }),
  ratingFloor: integerEnv('RATING_FLOOR', 0, { min: 0, max: 10000 }),
  gameMinutes: integerEnv('GAME_MINUTES', 10, { min: 1, max: 180 }),
  gameIncrementSeconds: integerEnv('GAME_INCREMENT_SECONDS', 0, { min: 0, max: 120 }),
  inviteTtlMinutes: integerEnv('INVITE_TTL_MINUTES', 30, { min: 1, max: 1440 }),
  siteName: String(process.env.SITE_NAME || 'NOVA CHESS').slice(0, 40),
  gasBridgeSecret: String(process.env.GAS_BRIDGE_SECRET || '').trim().slice(0, 255),
});

module.exports = { config };
