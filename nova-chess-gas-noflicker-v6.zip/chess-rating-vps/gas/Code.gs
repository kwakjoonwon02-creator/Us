/*
 * NOVA CHESS Google Apps Script gateway
 * 1) Set VPS_URL and BRIDGE_SECRET.
 * 2) BRIDGE_SECRET must equal GAS_BRIDGE_SECRET in the VPS .env.
 * 3) Deploy as Web app: execute as Me, access Anyone.
 * Browser -> google.script.run -> Apps Script -> VPS. No browser request goes directly to the VPS.
 */
const VPS_URL = 'https://julia-farmers-utilization-victory.trycloudflare.com';
const BRIDGE_SECRET = 'CHANGE_TO_THE_SAME_LONG_RANDOM_SECRET';
const POLL_MS = 1000;
const PIECES = ['wK', 'wQ', 'wR', 'wB', 'wN', 'wP', 'bK', 'bQ', 'bR', 'bB', 'bN', 'bP'];

function doGet() {
  assertConfig_();
  let html = cachedText_('ui:index:v1', '/');
  const css = cachedText_('ui:css:v1', '/styles.css');
  let app = cachedText_('ui:app:v2', '/app.js');
  const pieceMap = {};

  PIECES.forEach(function (name) {
    const svg = cachedText_('piece:' + name + ':v1', '/pieces/nova/' + name + '.svg');
    pieceMap[name] = 'data:image/svg+xml;base64,' + Utilities.base64Encode(svg, Utilities.Charset.UTF_8);
  });

  html = html
    .replace(/<link[^>]+rel=["']stylesheet["'][^>]*>/i, '<style>' + css + '</style>')
    .replace(/<link[^>]+rel=["']manifest["'][^>]*>/gi, '')
    .replace(/<link[^>]+rel=["']icon["'][^>]*>/gi, '')
    .replace(/<script[^>]+socket\.io[^>]*><\/script>/gi, '')
    .replace(/<script[^>]+\/app\.js[^>]*><\/script>/gi, '');

  PIECES.forEach(function (name) {
    html = html.split('/pieces/nova/' + name + '.svg').join(pieceMap[name]);
    app = app.split('/pieces/nova/' + name + '.svg').join(pieceMap[name]);
  });

  app = app.replace(
    "return `/pieces/nova/${white ? 'w' : 'b'}${pieceCode.toUpperCase()}.svg`;",
    "return window.NOVA_PIECES[(white ? 'w' : 'b') + pieceCode.toUpperCase()];"
  );
  app = app.replace(/\/pieces\/nova\/\$\{([^}]+)\}\.svg/g, '${window.NOVA_PIECES[$1]}');
  app = app.replace(
    /window\.setInterval\(renderClockValues,\s*\d+\)/,
    'window.setInterval(renderClockValues, 10)'
  );

  const injected = '<script>window.NOVA_PIECES=' + JSON.stringify(pieceMap)
    + ';window.NOVA_GAS_POLL_MS=' + POLL_MS + ';</script>'
    + '<script>' + clientBridgeSource_() + '</script>'
    + '<script>' + app + '</script>';
  html = html.replace('</body>', injected + '</body>');

  return HtmlService.createHtmlOutput(html)
    .setTitle('NOVA CHESS')
    .addMetaTag('viewport', 'width=device-width,initial-scale=1,viewport-fit=cover');
}

function bridgeApi(bridgeToken, path, method, body) {
  if (!/^\/api\//.test(String(path || ''))) throw new Error('허용되지 않은 API 경로입니다.');
  return proxy_(bridgeToken, String(path), String(method || 'GET').toUpperCase(), body, false);
}

function bridgeState(bridgeToken, lastGameId) {
  return proxy_(bridgeToken, '/api/gas/state', 'POST', { lastGameId: String(lastGameId || '') }, true);
}

function bridgeAction(bridgeToken, eventName, payload) {
  return proxy_(bridgeToken, '/api/gas/action', 'POST', {
    event: String(eventName || ''),
    payload: payload || {},
  }, true);
}

function proxy_(bridgeToken, path, method, body, gasOnly) {
  assertConfig_();
  const cookie = unpackCookie_(bridgeToken);
  const headers = { Accept: 'application/json' };
  if (cookie) headers.Cookie = cookie;
  if (gasOnly) headers['X-GAS-Bridge'] = BRIDGE_SECRET;

  const options = {
    method: method.toLowerCase(),
    headers: headers,
    muteHttpExceptions: true,
    followRedirects: false,
  };
  if (method !== 'GET' && method !== 'HEAD') {
    options.contentType = 'application/json';
    options.payload = JSON.stringify(body || {});
  }

  const response = UrlFetchApp.fetch(baseUrl_() + path, options);
  const status = response.getResponseCode();
  const responseHeaders = response.getAllHeaders();
  const setCookie = responseHeaders['Set-Cookie'] || responseHeaders['set-cookie'];
  let nextToken = String(bridgeToken || '');
  const sessionCookie = extractSessionCookie_(setCookie);
  if (sessionCookie !== null) nextToken = sessionCookie ? packCookie_(sessionCookie) : '';

  let data;
  try {
    data = JSON.parse(response.getContentText() || '{}');
  } catch (error) {
    data = { ok: false, code: 'INVALID_VPS_RESPONSE', message: 'VPS 응답을 읽지 못했습니다.' };
  }
  return { ok: status >= 200 && status < 300 && data.ok !== false, status: status, data: data, bridgeToken: nextToken };
}

function cachedText_(key, path) {
  const cache = CacheService.getScriptCache();
  const hit = cache.get(key);
  if (hit !== null) return hit;
  const response = UrlFetchApp.fetch(baseUrl_() + path, { muteHttpExceptions: true });
  if (response.getResponseCode() !== 200) throw new Error('VPS 파일을 불러오지 못했습니다: ' + path);
  const text = response.getContentText();
  if (text.length < 95000) cache.put(key, text, 300);
  return text;
}

function extractSessionCookie_(value) {
  if (value === undefined || value === null) return null;
  const joined = Array.isArray(value) ? value.join('\n') : String(value);
  const match = joined.match(/nova_chess_session=([^;]*)/);
  if (!match) return null;
  return match[1] ? 'nova_chess_session=' + match[1] : '';
}

function packCookie_(cookie) {
  const payload = Utilities.base64EncodeWebSafe(cookie, Utilities.Charset.UTF_8).replace(/=+$/, '');
  const signature = Utilities.base64EncodeWebSafe(
    Utilities.computeHmacSha256Signature(payload, BRIDGE_SECRET)
  ).replace(/=+$/, '');
  return payload + '.' + signature;
}

function unpackCookie_(token) {
  token = String(token || '');
  if (!token) return '';
  const parts = token.split('.');
  if (parts.length !== 2) throw new Error('브리지 세션이 올바르지 않습니다.');
  const expected = Utilities.base64EncodeWebSafe(
    Utilities.computeHmacSha256Signature(parts[0], BRIDGE_SECRET)
  ).replace(/=+$/, '');
  if (!safeEqual_(parts[1], expected)) throw new Error('브리지 세션 서명이 올바르지 않습니다.');
  return Utilities.newBlob(Utilities.base64DecodeWebSafe(parts[0])).getDataAsString();
}

function safeEqual_(a, b) {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i += 1) result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return result === 0;
}

function baseUrl_() {
  return String(VPS_URL).replace(/\/+$/, '');
}

function assertConfig_() {
  if (!/^https:\/\//i.test(baseUrl_())) throw new Error('VPS_URL에 HTTPS 주소를 입력하세요.');
  if (!BRIDGE_SECRET || BRIDGE_SECRET.length < 24 || /^CHANGE_/.test(BRIDGE_SECRET)) {
    throw new Error('BRIDGE_SECRET에 24자 이상의 임의 문자열을 입력하세요.');
  }
}

function clientBridgeSource_() {
  return String.raw`(function () {
  'use strict';
  var originalFetch = window.fetch ? window.fetch.bind(window) : null;
  var storageKey = 'nova_gas_bridge_v1';
  var bridgeToken = localStorage.getItem(storageKey) || '';

  function saveToken(value) {
    bridgeToken = value || '';
    if (bridgeToken) localStorage.setItem(storageKey, bridgeToken);
    else localStorage.removeItem(storageKey);
  }

  function gas(functionName, args) {
    return new Promise(function (resolve, reject) {
      var runner = google.script.run
        .withSuccessHandler(resolve)
        .withFailureHandler(function (error) { reject(new Error(error && error.message || String(error))); });
      runner[functionName].apply(runner, args || []);
    });
  }

  window.fetch = function (path, init) {
    if (typeof path !== 'string' || path.indexOf('/api/') !== 0) {
      if (!originalFetch) return Promise.reject(new Error('지원하지 않는 요청입니다.'));
      return originalFetch(path, init);
    }
    init = init || {};
    var body = null;
    if (init.body) {
      try { body = JSON.parse(init.body); } catch (_) { body = init.body; }
    }
    return gas('bridgeApi', [bridgeToken, path, init.method || 'GET', body]).then(function (result) {
      saveToken(result.bridgeToken);
      return {
        ok: result.ok,
        status: result.status,
        json: function () { return Promise.resolve(result.data); },
        text: function () { return Promise.resolve(JSON.stringify(result.data)); }
      };
    });
  };

  function GasSocket() {
    this.handlers = {};
    this.connected = false;
    this.closed = false;
    this.polling = false;
    this.currentGameId = '';
    this.lastGameId = '';
    this.finishedEmitted = '';
    var self = this;
    setTimeout(function () {
      if (self.closed) return;
      self.connected = true;
      self.fire('connect');
      self.poll();
      self.timer = setInterval(function () { self.poll(); }, window.NOVA_GAS_POLL_MS || 1000);
    }, 0);
  }

  GasSocket.prototype.on = function (name, handler) {
    (this.handlers[name] || (this.handlers[name] = [])).push(handler);
    return this;
  };
  GasSocket.prototype.once = function (name, handler) {
    var self = this;
    function once(value) { self.off(name, once); handler(value); }
    return this.on(name, once);
  };
  GasSocket.prototype.off = function (name, handler) {
    if (!this.handlers[name]) return this;
    this.handlers[name] = this.handlers[name].filter(function (item) { return item !== handler; });
    return this;
  };
  GasSocket.prototype.fire = function (name, value) {
    (this.handlers[name] || []).slice().forEach(function (handler) { handler(value); });
  };
  GasSocket.prototype.emit = function (name, payload, ack) {
    var self = this;
    if (typeof payload === 'function') { ack = payload; payload = {}; }
    gas('bridgeAction', [bridgeToken, name, payload || {}]).then(function (result) {
      saveToken(result.bridgeToken);
      if (typeof ack === 'function') ack(result.data);
      self.poll();
    }).catch(function (error) {
      if (typeof ack === 'function') ack({ ok: false, code: 'GAS_BRIDGE_ERROR', message: error.message });
    });
  };
  GasSocket.prototype.poll = function () {
    var self = this;
    if (self.closed || self.polling || !bridgeToken) return;
    self.polling = true;
    gas('bridgeState', [bridgeToken, self.lastGameId]).then(function (result) {
      saveToken(result.bridgeToken);
      if (!result.ok) throw new Error(result.data && result.data.message || '동기화 실패');
      var data = result.data;
      self.fire('lobby:stats', data.lobby || {});
      var game = data.game;
      if (game && game.status === 'active') {
        self.lastGameId = game.id;
        if (self.currentGameId !== game.id) {
          self.currentGameId = game.id;
          self.fire('game:started', game);
        } else {
          self.fire('game:state', game);
        }
      } else if (game && game.status === 'finished' && self.finishedEmitted !== game.id) {
        self.finishedEmitted = game.id;
        self.currentGameId = '';
        self.fire('game:finished', game);
        self.fire('leaderboard:changed');
      }
      if (!self.connected) { self.connected = true; self.fire('connect'); }
    }).catch(function (error) {
      if (self.connected) { self.connected = false; self.fire('disconnect', error.message); }
      self.fire('connect_error', error);
    }).finally(function () { self.polling = false; });
  };
  GasSocket.prototype.disconnect = function () {
    this.closed = true;
    this.connected = false;
    clearInterval(this.timer);
    this.fire('disconnect');
  };
  GasSocket.prototype.close = GasSocket.prototype.disconnect;
  window.io = function () { return new GasSocket(); };
})();`;
}
