(function () {
  'use strict';
  var originalFetch = window.fetch ? window.fetch.bind(window) : null;
  var storageKey = 'nova_reverse_bridge_v1';
  var bridgeToken = localStorage.getItem(storageKey) || '';

  function saveToken(value) {
    bridgeToken = value || '';
    if (bridgeToken) localStorage.setItem(storageKey, bridgeToken);
    else localStorage.removeItem(storageKey);
  }

  function reverse(request) {
    request = request || {};
    request.token = bridgeToken;
    return new Promise(function (resolve, reject) {
      google.script.run
        .withSuccessHandler(function (result) {
          saveToken(result && result.bridgeToken);
          resolve(result);
        })
        .withFailureHandler(function (error) {
          reject(new Error(error && error.message || String(error)));
        })
        .bridgeRequest(request);
    });
  }

  window.fetch = function (path, init) {
    if (typeof path !== 'string' || path.indexOf('/api/') !== 0) {
      if (!originalFetch) return Promise.reject(new Error('지원하지 않는 요청입니다.'));
      return originalFetch(path, init);
    }
    init = init || {};
    var body = null;
    if (init.body) {
      try { body = JSON.parse(init.body); } catch (_) { body = init.body; }
    }
    return reverse({ kind: 'api', path: path, method: init.method || 'GET', body: body }).then(function (result) {
      return {
        ok: Boolean(result && result.ok),
        status: Number(result && result.status || 500),
        json: function () { return Promise.resolve(result.data || {}); },
        text: function () { return Promise.resolve(JSON.stringify(result.data || {})); }
      };
    });
  };

  function GasSocket() {
    this.handlers = {};
    this.connected = false;
    this.closed = false;
    this.polling = false;
    this.currentGameId = '';
    this.lastGameId = '';
    this.finishedEmitted = '';
    this.pollTimer = null;
    var self = this;
    setTimeout(function () {
      if (self.closed) return;
      self.connected = true;
      self.fire('connect');
      self.schedulePoll(0);
    }, 0);
  }

  GasSocket.prototype.on = function (name, handler) {
    (this.handlers[name] || (this.handlers[name] = [])).push(handler);
    return this;
  };
  GasSocket.prototype.once = function (name, handler) {
    var self = this;
    function once(value) { self.off(name, once); handler(value); }
    return this.on(name, once);
  };
  GasSocket.prototype.off = function (name, handler) {
    if (!this.handlers[name]) return this;
    this.handlers[name] = this.handlers[name].filter(function (item) { return item !== handler; });
    return this;
  };
  GasSocket.prototype.fire = function (name, value) {
    (this.handlers[name] || []).slice().forEach(function (handler) { handler(value); });
  };
  GasSocket.prototype.emit = function (name, payload, ack) {
    var self = this;
    if (typeof payload === 'function') { ack = payload; payload = {}; }
    reverse({ kind: 'action', eventName: name, body: payload || {} }).then(function (result) {
      if (typeof ack === 'function') ack(result.data || { ok: false, message: '빈 VPS 응답' });
      self.schedulePoll(0);
    }).catch(function (error) {
      if (typeof ack === 'function') ack({ ok: false, code: 'REVERSE_BRIDGE_ERROR', message: error.message });
    });
  };
  GasSocket.prototype.schedulePoll = function (delayMs) {
    var self = this;
    if (self.closed) return;
    clearTimeout(self.pollTimer);
    self.pollTimer = setTimeout(function () {
      self.pollTimer = null;
      self.poll();
    }, Math.max(0, Number(delayMs || 0)));
  };
  GasSocket.prototype.poll = function () {
    var self = this;
    if (self.closed || self.polling) return;
    if (!bridgeToken) {
      self.schedulePoll(window.NOVA_GAS_POLL_MS || 25);
      return;
    }
    self.polling = true;
    var retryDelay = 0;
    reverse({ kind: 'state', lastGameId: self.lastGameId }).then(function (result) {
      if (!result || !result.ok) throw new Error(result && result.data && result.data.message || '동기화 실패');
      var data = result.data || {};
      self.fire('lobby:stats', data.lobby || {});
      var game = data.game;
      if (game && game.status === 'active') {
        self.lastGameId = game.id;
        if (self.currentGameId !== game.id) {
          self.currentGameId = game.id;
          self.fire('game:started', game);
        } else {
          self.fire('game:state', game);
        }
      } else if (game && game.status === 'finished' && self.finishedEmitted !== game.id) {
        self.finishedEmitted = game.id;
        self.currentGameId = '';
        self.fire('game:finished', game);
        self.fire('leaderboard:changed');
      }
      if (!self.connected) { self.connected = true; self.fire('connect'); }
    }).catch(function (error) {
      retryDelay = self.connected ? 75 : 250;
      if (self.connected) { self.connected = false; self.fire('disconnect', error.message); }
      self.fire('connect_error', error);
    }).finally(function () {
      self.polling = false;
      self.schedulePoll(retryDelay);
    });
  };
  GasSocket.prototype.disconnect = function () {
    this.closed = true;
    this.connected = false;
    clearTimeout(this.pollTimer);
    this.fire('disconnect');
  };
  GasSocket.prototype.close = GasSocket.prototype.disconnect;
  window.io = function () { return new GasSocket(); };
})();
