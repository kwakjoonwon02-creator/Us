(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const elements = {
    loadingView: $('loadingView'),
    lobbyView: $('lobbyView'),
    gameView: $('gameView'),
    siteName: $('siteName'),
    onlineCount: $('onlineCount'),
    accountButton: $('accountButton'),
    accountAvatar: $('accountAvatar'),
    accountHandle: $('accountHandle'),
    accountRating: $('accountRating'),
    brandButton: $('brandButton'),
    gameLogoButton: $('gameLogoButton'),
    quickMatchButton: $('quickMatchButton'),
    openInviteButton: $('openInviteButton'),
    openSpectateButton: $('openSpectateButton'),
    profileAccountAction: $('profileAccountAction'),
    profileTypeBadge: $('profileTypeBadge'),
    profileAvatar: $('profileAvatar'),
    profileHandle: $('profileHandle'),
    profileRating: $('profileRating'),
    profileRecord: $('profileRecord'),
    profileGames: $('profileGames'),
    profileRatedGames: $('profileRatedGames'),
    profileWinRate: $('profileWinRate'),
    guestNotice: $('guestNotice'),
    heroOnline: $('heroOnline'),
    activeGameCount: $('activeGameCount'),
    searchingCount: $('searchingCount'),
    timeControlLabel: $('timeControlLabel'),
    leaderboardList: $('leaderboardList'),
    recentGamesList: $('recentGamesList'),
    refreshLeaderboardButton: $('refreshLeaderboardButton'),
    queueOverlay: $('queueOverlay'),
    queueTime: $('queueTime'),
    cancelQueueButton: $('cancelQueueButton'),
    modalRoot: $('modalRoot'),
    modalBackdrop: $('modalBackdrop'),
    modalPanel: $('modalPanel'),
    modalContent: $('modalContent'),
    modalCloseButton: $('modalCloseButton'),
    promotionOverlay: $('promotionOverlay'),
    promotionChoices: $('promotionChoices'),
    toastRegion: $('toastRegion'),
    connectionBanner: $('connectionBanner'),
    gameTitle: $('gameTitle'),
    gameRatedBadge: $('gameRatedBadge'),
    gameConnectionBadge: $('gameConnectionBadge'),
    opponentPanel: $('opponentPanel'),
    myPanel: $('myPanel'),
    chessBoard: $('chessBoard'),
    turnStatus: $('turnStatus'),
    turnDetail: $('turnDetail'),
    moveList: $('moveList'),
    moveCount: $('moveCount'),
    chatMessages: $('chatMessages'),
    chatForm: $('chatForm'),
    chatInput: $('chatInput'),
    chatSendButton: $('chatSendButton'),
    drawOfferBox: $('drawOfferBox'),
    offerDrawButton: $('offerDrawButton'),
    acceptDrawButton: $('acceptDrawButton'),
    declineDrawButton: $('declineDrawButton'),
    resignButton: $('resignButton'),
    gameIdLabel: $('gameIdLabel'),
    gameModeLabel: $('gameModeLabel'),
    currentYear: $('currentYear'),
  };

  const state = {
    site: null,
    me: null,
    leaderboard: [],
    recentGames: [],
    lobby: { online: 0, searching: 0, activeGames: 0 },
    socket: null,
    connected: false,
    game: null,
    finishedGame: null,
    selectedSquare: null,
    moving: false,
    queueing: false,
    queueStartedAt: 0,
    queueTimer: null,
    clockTimer: null,
    spectatorSyncRunning: false,
    spectatingHandle: '',
    modalOnClose: null,
    modalLocked: false,
    pendingPromotion: null,
    inviteCode: null,
    pendingFlights: [],
    lastMotionKey: null,
    drag: null,
    suppressBoardClickUntil: 0,
    lastChatKey: '',
  };

  const PIECE_NAMES = {
    P: '백 폰', N: '백 나이트', B: '백 비숍', R: '백 룩', Q: '백 퀸', K: '백 킹',
    p: '흑 폰', n: '흑 나이트', b: '흑 비숍', r: '흑 룩', q: '흑 퀸', k: '흑 킹',
  };
  const UI_FRAME_MS = 10;

  function clientNow() {
    return window.performance?.now?.() ?? Date.now();
  }

  function stampClockReceipt(game) {
    if (!game?.clocks) return game;
    game.clocks = {
      ...game.clocks,
      clientReceivedAt: clientNow(),
    };
    return game;
  }

  function pieceAsset(pieceCode) {
    const white = pieceCode === pieceCode.toUpperCase();
    return `/pieces/nova/${white ? 'w' : 'b'}${pieceCode.toUpperCase()}.svg`;
  }

  function createPieceImage(pieceCode, className = 'piece board-piece') {
    const image = document.createElement('img');
    image.className = className;
    image.src = pieceAsset(pieceCode);
    image.alt = PIECE_NAMES[pieceCode] || '체스 기물';
    image.draggable = false;
    image.decoding = 'async';
    return image;
  }

  const REASON_LABELS = {
    checkmate: '체크메이트',
    resignation: '기권',
    timeout: '시간 종료',
    stalemate: '스테일메이트',
    threefold_repetition: '3회 동형 반복',
    insufficient_material: '기물 부족',
    fifty_move_rule: '50수 규칙',
    draw_agreement: '합의 무승부',
    draw: '무승부',
    restore_error: '서버 복구 오류',
  };

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function initial(value) {
    return [...String(value || 'G').trim()][0]?.toUpperCase() || 'G';
  }

  function formatNumber(value) {
    return new Intl.NumberFormat('ko-KR').format(Number(value || 0));
  }

  function formatDate(timestamp) {
    if (!timestamp) return '';
    return new Intl.DateTimeFormat('ko-KR', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(timestamp));
  }

  function formatClock(milliseconds) {
    const safe = Math.max(0, Number(milliseconds || 0));
    const totalSeconds = Math.ceil(safe / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastRegion.appendChild(toast);
    window.setTimeout(() => toast.remove(), 3400);
  }

  async function api(path, options = {}) {
    const init = {
      method: options.method || 'GET',
      credentials: 'same-origin',
      headers: { ...(options.headers || {}) },
    };
    if (options.body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(options.body);
    }

    const response = await fetch(path, init);
    let data;
    try {
      data = await response.json();
    } catch {
      data = { ok: false, message: '서버 응답을 읽을 수 없습니다.' };
    }
    if (!response.ok || data.ok === false) {
      const error = new Error(data.message || '요청을 처리하지 못했습니다.');
      error.code = data.code || 'REQUEST_FAILED';
      error.status = response.status;
      throw error;
    }
    return data;
  }

  function emitAck(eventName, payload = {}) {
    return new Promise((resolve, reject) => {
      if (!state.socket?.connected) {
        reject(new Error('서버에 연결되어 있지 않습니다.'));
        return;
      }
      const timeout = window.setTimeout(() => reject(new Error('서버 응답 시간이 초과되었습니다.')), 9000);
      state.socket.emit(eventName, payload, (response) => {
        window.clearTimeout(timeout);
        if (!response?.ok) {
          const error = new Error(response?.message || '요청을 처리하지 못했습니다.');
          error.code = response?.code || 'SOCKET_ERROR';
          reject(error);
          return;
        }
        resolve(response);
      });
    });
  }

  function applyBootstrap(data, { preserveGame = false } = {}) {
    state.site = data.site;
    state.me = data.me;
    state.leaderboard = data.leaderboard || [];
    state.recentGames = data.recentGames || [];
    state.lobby = data.lobby || state.lobby;
    if (!preserveGame) state.game = stampClockReceipt(data.activeGame || null);

    document.title = state.site?.name || 'NOVA CHESS';
    elements.siteName.textContent = state.site?.name || 'NOVA CHESS';
    elements.timeControlLabel.textContent = `${state.site?.gameMinutes || 10}분${state.site?.incrementSeconds ? ` + ${state.site.incrementSeconds}초` : ''} · 레이팅 반영`;
    renderAll({ skipGame: preserveGame });
  }

  async function loadBootstrap() {
    try {
      const data = await api('/api/bootstrap');
      applyBootstrap(data);
      connectSocket();
    } catch (error) {
      elements.loadingView.innerHTML = '';
      const box = document.createElement('div');
      box.className = 'empty-state';
      box.innerHTML = '<span>♞</span><strong>서버에 연결하지 못했습니다</strong>';
      const detail = document.createElement('p');
      detail.textContent = error.message;
      box.appendChild(detail);
      elements.loadingView.appendChild(box);
      showToast(error.message, 'error');
    }
  }

  function connectSocket() {
    if (state.socket) state.socket.disconnect();
    state.socket = window.io({
      transports: ['websocket', 'polling'],
      upgrade: true,
      rememberUpgrade: true,
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 250,
      reconnectionDelayMax: 2000,
      timeout: 5000,
    });

    state.socket.on('connect', () => {
      state.connected = true;
      elements.connectionBanner.hidden = true;
      updateConnectionUi();
      if (state.game?.status === 'active') {
        emitAck('game:sync', { gameId: state.game.id })
          .then((response) => handleGameState(response.game))
          .catch(() => {});
      }
      window.setTimeout(resumePendingInvite, 0);
    });

    state.socket.on('disconnect', () => {
      state.connected = false;
      elements.connectionBanner.hidden = false;
      updateConnectionUi();
    });

    state.socket.on('connect_error', (error) => {
      state.connected = false;
      elements.connectionBanner.hidden = false;
      elements.connectionBanner.textContent = error?.message || '서버와 다시 연결하는 중입니다…';
      updateConnectionUi();
    });

    state.socket.on('lobby:stats', (lobby) => {
      state.lobby = lobby;
      renderLobbyStats();
    });

    state.socket.on('game:started', handleGameState);
    state.socket.on('game:state', handleGameState);

    state.socket.on('game:clock', (clock) => {
      if (!state.game || state.game.id !== clock.gameId || state.game.status !== 'active') return;
      state.game.turn = clock.turn;
      state.game.clocks = {
        ...(state.game.clocks || {}),
        whiteMs: clock.whiteMs,
        blackMs: clock.blackMs,
        serverNow: clock.serverNow,
        clientReceivedAt: clientNow(),
      };
      renderClockValues();
      renderGameStatus();
    });

    state.socket.on('game:finished', handleGameFinished);
    state.socket.on('game:notice', (notice) => showToast(notice.message, 'info'));
    state.socket.on('leaderboard:changed', () => {
      window.setTimeout(() => refreshDashboardData({ preserveGame: Boolean(state.game) }), 250);
    });
  }

  function updateConnectionUi() {
    if (!elements.gameConnectionBadge) return;
    elements.gameConnectionBadge.classList.toggle('connected', state.connected);
    elements.gameConnectionBadge.innerHTML = state.connected ? '<i></i> LIVE' : '<i></i> OFFLINE';
  }

  async function refreshDashboardData({ preserveGame = false } = {}) {
    try {
      const data = await api('/api/bootstrap');
      applyBootstrap(data, { preserveGame });
    } catch (error) {
      showToast(error.message, 'error');
    }
  }

  function renderAll({ skipGame = false } = {}) {
    elements.loadingView.hidden = true;
    renderHeader();
    renderProfile();
    renderLobbyStats();
    renderLeaderboard();
    renderRecentGames();
    if (state.game && !skipGame) renderGame();
    else if (!state.game) showLobby();
  }

  function renderHeader() {
    if (!state.me) return;
    const avatar = initial(state.me.handle);
    elements.accountAvatar.textContent = avatar;
    elements.accountHandle.textContent = state.me.handle;
    elements.accountRating.textContent = formatNumber(state.me.rating);
    elements.accountButton.classList.toggle('member-account', Boolean(state.me.ratedEligible));
  }

  function renderProfile() {
    if (!state.me) return;
    const games = Number(state.me.gamesPlayed || 0);
    const winRate = games > 0 ? Math.round((Number(state.me.wins || 0) / games) * 100) : 0;
    const ratedEligible = Boolean(state.me.ratedEligible);
    elements.profileTypeBadge.textContent = ratedEligible ? 'ACCOUNT' : state.me.isGuest ? 'GUEST' : 'SETUP';
    elements.profileTypeBadge.classList.toggle('account-badge', ratedEligible);
    elements.profileAvatar.textContent = initial(state.me.handle);
    elements.profileHandle.textContent = state.me.handle;
    elements.profileRating.textContent = formatNumber(state.me.rating);
    elements.profileRecord.textContent = `${state.me.wins}승 ${state.me.draws}무 ${state.me.losses}패`;
    elements.profileGames.textContent = formatNumber(games);
    elements.profileRatedGames.textContent = formatNumber(state.me.ratedGames);
    elements.profileWinRate.textContent = `${winRate}%`;
    elements.profileAccountAction.textContent = ratedEligible ? '계정 정보' : '계정 만들고 레이팅 시작';
    elements.profileAccountAction.classList.toggle('account-login-action', !ratedEligible);
    elements.guestNotice.hidden = ratedEligible;

    const quickTitle = elements.quickMatchButton.querySelector('strong');
    elements.quickMatchButton.classList.toggle('account-locked', !ratedEligible);
    if (quickTitle) quickTitle.textContent = ratedEligible ? '빠른 레이팅 대전' : '회원가입 후 레이팅 대전';
    elements.timeControlLabel.textContent = ratedEligible
      ? `${state.site?.gameMinutes || 10}분${state.site?.incrementSeconds ? ` + ${state.site.incrementSeconds}초` : ''} · 레이팅 반영`
      : '로그인 계정만 참여 가능';
  }

  function renderLobbyStats() {
    const lobby = state.lobby || {};
    const online = Number(lobby.online || 0);
    elements.onlineCount.textContent = formatNumber(online);
    elements.heroOnline.textContent = formatNumber(online);
    elements.activeGameCount.textContent = formatNumber(lobby.activeGames || 0);
    elements.searchingCount.textContent = formatNumber(lobby.searching || 0);
  }

  function renderLeaderboard() {
    elements.leaderboardList.textContent = '';
    if (!state.leaderboard.length) {
      elements.leaderboardList.innerHTML = '<div class="empty-state"><span>♛</span><strong>아직 순위가 없습니다</strong><p>첫 레이팅 대국을 완료하면 이곳에 이름이 올라갑니다.</p></div>';
      return;
    }

    state.leaderboard.forEach((player, index) => {
      const row = document.createElement('div');
      row.className = `leaderboard-row${player.id === state.me?.id ? ' is-me' : ''}`;
      const rank = document.createElement('span');
      rank.className = `rank-number${index < 3 ? ' top-rank' : ''}`;
      rank.textContent = String(index + 1).padStart(2, '0');

      const avatar = document.createElement('span');
      avatar.className = 'avatar rank-avatar';
      avatar.textContent = initial(player.handle);

      const copy = document.createElement('div');
      copy.className = 'rank-copy';
      const handle = document.createElement('strong');
      handle.textContent = player.handle;
      const record = document.createElement('small');
      record.textContent = `${player.wins}승 ${player.draws}무 ${player.losses}패${player.isGuest ? ' · GUEST' : ''}`;
      copy.append(handle, record);

      const rating = document.createElement('span');
      rating.className = 'rank-rating';
      rating.textContent = `${formatNumber(player.rating)} RP`;
      row.append(rank, avatar, copy, rating);
      elements.leaderboardList.appendChild(row);
    });
  }

  function renderRecentGames() {
    elements.recentGamesList.textContent = '';
    if (!state.recentGames.length) {
      elements.recentGamesList.innerHTML = '<div class="empty-state"><span>♜</span><strong>아직 완료한 대국이 없습니다</strong><p>빠른 대전이나 친구 초대로 첫 경기를 시작해 보세요.</p></div>';
      return;
    }

    for (const game of state.recentGames) {
      const row = document.createElement('div');
      row.className = 'recent-row';

      const mark = document.createElement('span');
      mark.className = `outcome-mark outcome-${game.outcome}`;
      mark.textContent = game.outcome === 'win' ? 'W' : game.outcome === 'loss' ? 'L' : 'D';

      const copy = document.createElement('div');
      copy.className = 'recent-copy';
      const opponent = document.createElement('strong');
      opponent.textContent = `vs ${game.opponent}`;
      const meta = document.createElement('small');
      meta.textContent = `${game.color === 'white' ? '백' : '흑'} · ${REASON_LABELS[game.reason] || '대국 종료'} · ${formatDate(game.finishedAt)}`;
      copy.append(opponent, meta);

      const result = document.createElement('span');
      result.className = 'recent-result';
      result.textContent = game.result || '—';

      const delta = document.createElement('span');
      const amount = Number(game.ratingDelta || 0);
      delta.className = `rating-delta ${amount > 0 ? 'positive' : amount < 0 ? 'negative' : 'neutral'}`;
      delta.textContent = game.rated ? `${amount > 0 ? '+' : ''}${amount}` : 'UNRATED';

      row.append(mark, copy, result, delta);
      elements.recentGamesList.appendChild(row);
    }
  }

  function showLobby() {
    elements.loadingView.hidden = true;
    elements.gameView.hidden = true;
    elements.lobbyView.hidden = false;
    stopClockTicker();
    stopSpectating();
  }

  function showGame() {
    elements.loadingView.hidden = true;
    elements.lobbyView.hidden = true;
    elements.gameView.hidden = false;
  }

  function prepareBoardMotion(nextGame) {
    state.pendingFlights = [];
    const previous = state.game;
    const move = nextGame?.lastMove;
    const previousPly = previous?.history?.length || 0;
    const nextPly = nextGame?.history?.length || 0;
    const motionKey = move ? `${nextGame.id}:${nextPly}:${move.from}-${move.to}` : null;
    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

    if (
      reduceMotion
      || !previous
      || previous.id !== nextGame?.id
      || nextPly !== previousPly + 1
      || !move?.from
      || !move?.to
      || state.lastMotionKey === motionKey
    ) return;

    const oldPosition = parseFen(previous.fen);
    const movingPieceCode = oldPosition.get(move.from);
    const sourcePiece = elements.chessBoard.querySelector(`[data-square="${move.from}"] .piece`);
    if (!movingPieceCode || !sourcePiece) return;

    state.lastMotionKey = motionKey;
    const capturedSquare = oldPosition.has(move.to)
      ? move.to
      : move.captured && movingPieceCode.toLowerCase() === 'p'
        ? `${move.to[0]}${move.from[1]}`
        : null;
    const capturedPiece = capturedSquare
      ? elements.chessBoard.querySelector(`[data-square="${capturedSquare}"] .piece`)
      : null;

    state.pendingFlights.push({
      from: move.from,
      to: move.to,
      node: sourcePiece.cloneNode(true),
      captured: capturedPiece ? { square: capturedSquare, node: capturedPiece.cloneNode(true) } : null,
    });

    if (movingPieceCode.toLowerCase() === 'k' && Math.abs(move.to.charCodeAt(0) - move.from.charCodeAt(0)) === 2) {
      const kingSide = move.to[0] === 'g';
      const rank = move.from[1];
      const rookFrom = `${kingSide ? 'h' : 'a'}${rank}`;
      const rookTo = `${kingSide ? 'f' : 'd'}${rank}`;
      const rook = elements.chessBoard.querySelector(`[data-square="${rookFrom}"] .piece`);
      if (rook) state.pendingFlights.push({ from: rookFrom, to: rookTo, node: rook.cloneNode(true), captured: null });
    }
  }

  function playPendingFlights() {
    const flights = state.pendingFlights.splice(0);
    if (!flights.length) return;
    const boardRect = elements.chessBoard.getBoundingClientRect();

    for (const flight of flights) {
      const fromSquare = elements.chessBoard.querySelector(`[data-square="${flight.from}"]`);
      const toSquare = elements.chessBoard.querySelector(`[data-square="${flight.to}"]`);
      if (!fromSquare || !toSquare) continue;

      const fromRect = fromSquare.getBoundingClientRect();
      const toRect = toSquare.getBoundingClientRect();
      const destinationPiece = toSquare.querySelector('.piece');
      destinationPiece?.classList.add('piece-arriving');

      if (flight.captured) {
        const capturedSquare = elements.chessBoard.querySelector(`[data-square="${flight.captured.square}"]`);
        if (capturedSquare) {
          const capturedRect = capturedSquare.getBoundingClientRect();
          const capturedGhost = document.createElement('span');
          capturedGhost.className = 'capture-ghost';
          capturedGhost.style.left = `${capturedRect.left - boardRect.left}px`;
          capturedGhost.style.top = `${capturedRect.top - boardRect.top}px`;
          capturedGhost.style.width = `${capturedRect.width}px`;
          capturedGhost.style.height = `${capturedRect.height}px`;
          capturedGhost.appendChild(flight.captured.node);
          elements.chessBoard.appendChild(capturedGhost);
          const captureAnimation = capturedGhost.animate?.([
            { opacity: 1, transform: 'scale(1)' },
            { opacity: 0, transform: 'scale(.72)' },
          ], { duration: 75, easing: 'ease-out', fill: 'forwards' });
          if (captureAnimation?.finished) captureAnimation.finished.catch(() => {}).finally(() => capturedGhost.remove());
          else window.setTimeout(() => capturedGhost.remove(), 90);
        }
      }

      const ghost = document.createElement('span');
      ghost.className = 'piece-flight';
      ghost.style.left = `${fromRect.left - boardRect.left}px`;
      ghost.style.top = `${fromRect.top - boardRect.top}px`;
      ghost.style.width = `${fromRect.width}px`;
      ghost.style.height = `${fromRect.height}px`;
      ghost.appendChild(flight.node);
      elements.chessBoard.appendChild(ghost);

      const cleanup = () => {
        ghost.remove();
        destinationPiece?.classList.remove('piece-arriving');
        destinationPiece?.classList.add('piece-landed');
        window.setTimeout(() => destinationPiece?.classList.remove('piece-landed'), 100);
      };
      const animation = ghost.animate?.([
        { transform: 'translate3d(0, 0, 0) scale(1)' },
        { transform: `translate3d(${toRect.left - fromRect.left}px, ${toRect.top - fromRect.top}px, 0) scale(1.025)` },
      ], { duration: 90, easing: 'cubic-bezier(.2,.75,.25,1)', fill: 'forwards' });
      if (animation?.finished) animation.finished.catch(() => {}).finally(cleanup);
      else window.setTimeout(cleanup, 105);
    }
  }

  function handleGameState(game) {
    if (!game) return;
    stampClockReceipt(game);
    const previous = state.game;
    const sameActiveGame = Boolean(
      previous
      && previous.id === game.id
      && previous.status === 'active'
      && game.status === 'active'
    );
    const boardChanged = !sameActiveGame || previous.fen !== game.fen;

    if (boardChanged) prepareBoardMotion(game);
    state.game = game;
    state.finishedGame = null;

    if (boardChanged) {
      state.selectedSquare = null;
      state.moving = false;
      stopQueueOverlay();
      state.inviteCode = null;
      if (!sameActiveGame) closeModal(true);
      renderGame();
      return;
    }

    // Clock/presence/draw synchronization must not rebuild the board or modal.
    // Rebuilding here interrupts dragging, selection, and action button clicks.
    updateConnectionUi();
    renderClockValues();
    renderGameStatus();
    renderChat();
  }

  async function handleGameFinished(finished) {
    if (!finished || !state.me) return;
    stopQueueOverlay();
    state.finishedGame = finished;
    state.selectedSquare = null;
    state.moving = false;

    const previous = state.game || {};
    const nextGame = {
      ...previous,
      ...finished,
      color: finished.white.id === state.me.id ? 'white' : 'black',
      turn: previous.turn || 'white',
      legalMoves: [],
      clocks: previous.clocks || {
        whiteMs: 0,
        blackMs: 0,
        serverNow: Date.now(),
        clientReceivedAt: clientNow(),
        incrementMs: 0,
      },
      status: 'finished',
      drawOffer: null,
    };
    prepareBoardMotion(nextGame);
    state.game = nextGame;
    renderGame();
    stopClockTicker();
    await refreshDashboardData({ preserveGame: true });
    openResultModal(finished);
  }

  function renderGame() {
    if (!state.game) return;
    showGame();
    const game = state.game;
    const modeLabel = game.mode === 'invite' ? '친구 초대 대전' : '빠른 대전';
    const title = game.rated ? `${modeLabel} · 레이팅` : `${modeLabel} · 일반`;
    elements.gameTitle.textContent = game.spectator ? `관전 · ${title}` : title;
    elements.gameRatedBadge.textContent = game.rated ? 'RATED' : 'UNRATED';
    elements.gameRatedBadge.classList.toggle('rated', game.rated);
    elements.gameIdLabel.textContent = `GAME ${String(game.id).slice(0, 8).toUpperCase()}`;
    elements.gameModeLabel.textContent = modeLabel;
    updateConnectionUi();
    renderPlayerPanels();
    renderBoard();
    renderMoves();
    renderChat();
    renderGameStatus();
    if (game.status === 'active') {
      startClockTicker();
    } else {
      stopClockTicker();
    }
  }

  function myColor() {
    if (!state.game) return null;
    if (state.game.color) return state.game.color;
    if (state.game.white?.id === state.me?.id) return 'white';
    if (state.game.black?.id === state.me?.id) return 'black';
    return null;
  }

  function renderPlayerPanels() {
    const game = state.game;
    if (game.spectator) {
      renderPlayerPanel(elements.myPanel, game.white, 'white', false);
      renderPlayerPanel(elements.opponentPanel, game.black, 'black', false);
      renderClockValues();
      return;
    }
    const color = myColor();
    const mine = color === 'white' ? game.white : game.black;
    const opponent = color === 'white' ? game.black : game.white;
    const mineColor = color;
    const opponentColor = color === 'white' ? 'black' : 'white';

    renderPlayerPanel(elements.myPanel, mine, mineColor, true);
    renderPlayerPanel(elements.opponentPanel, opponent, opponentColor, false);
    renderClockValues();
  }

  function renderPlayerPanel(container, player, color, isMe) {
    const activeTurn = state.game.status === 'active' && state.game.turn === color;
    container.classList.toggle('active-turn', activeTurn);
    const online = isMe ? state.connected : Boolean(player?.online);
    const pieceCode = color === 'white' ? 'K' : 'k';
    const clockId = isMe ? 'myClock' : 'opponentClock';
    container.innerHTML = `
      <span class="player-piece-icon"><img src="${pieceAsset(pieceCode)}" alt="${PIECE_NAMES[pieceCode]}" draggable="false"></span>
      <div class="player-info">
        <strong>${escapeHtml(player?.handle || 'Player')}${isMe ? ' (나)' : ''}</strong>
        <small><span class="presence-label ${online ? '' : 'offline'}">${online ? '온라인' : '연결 끊김'}</span> · ${formatNumber(player?.rating ?? player?.ratingBefore ?? 100)} RP</small>
      </div>
      <span id="${clockId}" class="player-clock">00:00</span>
    `;
  }

  function currentClientClocks() {
    const game = state.game;
    const base = game?.clocks || { whiteMs: 0, blackMs: 0, serverNow: Date.now() };
    let whiteMs = Number(base.whiteMs || 0);
    let blackMs = Number(base.blackMs || 0);
    if (game?.status === 'active') {
      const receivedAt = Number(base.clientReceivedAt);
      const elapsed = Number.isFinite(receivedAt)
        ? Math.max(0, clientNow() - receivedAt)
        : 0;
      if (game.turn === 'white') whiteMs = Math.max(0, whiteMs - elapsed);
      else blackMs = Math.max(0, blackMs - elapsed);
    }
    return { whiteMs, blackMs };
  }

  function renderClockValues() {
    if (!state.game) return;
    const clocks = currentClientClocks();
    const color = myColor();
    const myMs = state.game.spectator || color === 'white' ? clocks.whiteMs : clocks.blackMs;
    const opponentMs = state.game.spectator || color === 'white' ? clocks.blackMs : clocks.whiteMs;
    const mine = $('myClock');
    const opponent = $('opponentClock');
    if (mine) {
      mine.textContent = formatClock(myMs);
      mine.classList.toggle('low-time', state.game.status === 'active' && myMs <= 30_000);
    }
    if (opponent) {
      opponent.textContent = formatClock(opponentMs);
      opponent.classList.toggle('low-time', state.game.status === 'active' && opponentMs <= 30_000);
    }
  }

  function startClockTicker() {
    if (state.clockTimer) return;
    let lastPaintAt = 0;
    const paint = (timestamp) => {
      if (!state.clockTimer) return;
      if (timestamp - lastPaintAt >= UI_FRAME_MS) {
        lastPaintAt = timestamp;
        renderClockValues();
      }
      state.clockTimer = window.requestAnimationFrame(paint);
    };
    state.clockTimer = window.requestAnimationFrame(paint);
  }

  function stopClockTicker() {
    if (!state.clockTimer) return;
    window.cancelAnimationFrame(state.clockTimer);
    state.clockTimer = null;
  }

  function renderChat() {
    if (!elements.chatMessages || !state.game) return;
    const readOnly = Boolean(state.game.spectator || state.game.status !== 'active');
    elements.chatInput.disabled = readOnly;
    elements.chatSendButton.disabled = readOnly;
    elements.chatInput.placeholder = state.game.spectator ? '관전 중에는 채팅할 수 없습니다' : '메시지 입력';
    const messages = Array.isArray(state.game.chat) ? state.game.chat : [];
    const chatKey = `${state.game.id}:${messages.map((item) => item.id).join(',')}`;
    if (chatKey === state.lastChatKey) return;
    state.lastChatKey = chatKey;
    elements.chatMessages.textContent = '';

    if (!messages.length) {
      const empty = document.createElement('p');
      empty.className = 'chat-empty';
      empty.textContent = state.game.spectator ? '관전자에게 채팅은 공개되지 않습니다.' : '상대에게 메시지를 보내보세요.';
      elements.chatMessages.appendChild(empty);
      return;
    }

    for (const item of messages) {
      const mine = Number(item.userId) === Number(state.me?.id);
      const row = document.createElement('div');
      row.className = `chat-message ${mine ? 'mine' : 'theirs'}`;
      const meta = document.createElement('span');
      meta.textContent = mine ? '나' : item.handle || '상대';
      const text = document.createElement('p');
      text.textContent = item.message || '';
      row.append(meta, text);
      elements.chatMessages.appendChild(row);
    }
    elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
  }

  function parseFen(fen) {
    const map = new Map();
    const ranks = String(fen || '').split(' ')[0]?.split('/') || [];
    for (let row = 0; row < ranks.length; row += 1) {
      let fileIndex = 0;
      for (const token of ranks[row]) {
        if (/\d/.test(token)) {
          fileIndex += Number(token);
        } else {
          const square = `${String.fromCharCode(97 + fileIndex)}${8 - row}`;
          map.set(square, token);
          fileIndex += 1;
        }
      }
    }
    return map;
  }

  function renderBoard() {
    const game = state.game;
    const position = parseFen(game.fen);
    const color = myColor() || 'white';
    const files = color === 'black' ? ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'] : ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
    const ranks = color === 'black' ? [1, 2, 3, 4, 5, 6, 7, 8] : [8, 7, 6, 5, 4, 3, 2, 1];
    const legalMoves = game.legalMoves || [];
    const legalFrom = new Set(legalMoves.map((move) => move.from));
    const targets = state.selectedSquare
      ? legalMoves.filter((move) => move.from === state.selectedSquare)
      : [];
    const targetSquares = new Set(targets.map((move) => move.to));
    const lastMove = game.lastMove || null;

    elements.chessBoard.textContent = '';
    ranks.forEach((rank, rowIndex) => {
      files.forEach((file, columnIndex) => {
        const squareName = `${file}${rank}`;
        const fileIndex = file.charCodeAt(0) - 97;
        const isLight = (fileIndex + rank) % 2 === 0;
        const pieceCode = position.get(squareName);
        const square = document.createElement('button');
        square.type = 'button';
        square.className = `square ${isLight ? 'light' : 'dark'}`;
        square.dataset.square = squareName;
        square.setAttribute('role', 'gridcell');
        square.setAttribute('aria-label', `${squareName}${pieceCode ? ` ${pieceCode}` : ''}`);

        if (lastMove && (lastMove.from === squareName || lastMove.to === squareName)) square.classList.add('last-move');
        if (state.selectedSquare === squareName) square.classList.add('selected');
        if (game.checkSquare === squareName) square.classList.add('check-square');
        if (legalFrom.has(squareName)) square.classList.add('selectable');
        if (targetSquares.has(squareName)) {
          square.classList.add('legal-target');
          if (pieceCode) square.classList.add('legal-capture');
        }

        if (pieceCode) {
          square.appendChild(createPieceImage(pieceCode));
        }

        if (rowIndex === 7) {
          const coordinate = document.createElement('span');
          coordinate.className = 'coord coord-file';
          coordinate.textContent = file;
          square.appendChild(coordinate);
        }
        if (columnIndex === 0) {
          const coordinate = document.createElement('span');
          coordinate.className = 'coord coord-rank';
          coordinate.textContent = String(rank);
          square.appendChild(coordinate);
        }

        square.addEventListener('click', () => handleSquareClick(squareName));
        elements.chessBoard.appendChild(square);
      });
    });
    playPendingFlights();
  }

  function handleSquareClick(square) {
    if (Date.now() < state.suppressBoardClickUntil) return;
    const game = state.game;
    if (!game || game.status !== 'active' || state.moving) return;
    const moves = game.legalMoves || [];
    const selectableMoves = moves.filter((move) => move.from === square);

    if (!state.selectedSquare) {
      if (selectableMoves.length) {
        state.selectedSquare = square;
        renderBoard();
      }
      return;
    }

    const targetMoves = moves.filter((move) => move.from === state.selectedSquare && move.to === square);
    if (targetMoves.length) {
      if (targetMoves.some((move) => move.promotion)) {
        openPromotion(targetMoves);
      } else {
        sendMove(state.selectedSquare, square);
      }
      return;
    }

    if (selectableMoves.length) state.selectedSquare = square;
    else state.selectedSquare = null;
    renderBoard();
  }

  function boardPointerDown(event) {
    if (event.button !== 0 || !state.game || state.game.status !== 'active' || state.moving) return;
    const squareElement = event.target.closest('.square');
    if (!squareElement || !elements.chessBoard.contains(squareElement)) return;
    const square = squareElement.dataset.square;
    const legalMoves = (state.game.legalMoves || []).filter((move) => move.from === square);
    if (!legalMoves.length || !squareElement.querySelector('.piece')) return;

    state.drag = {
      pointerId: event.pointerId,
      from: square,
      startX: event.clientX,
      startY: event.clientY,
      active: false,
      ghost: null,
      hoverSquare: null,
    };
    elements.chessBoard.setPointerCapture?.(event.pointerId);
  }

  function boardPointerMove(event) {
    const drag = state.drag;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const distance = Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY);
    if (!drag.active && distance < 7) return;

    if (!drag.active) {
      drag.active = true;
      state.selectedSquare = drag.from;
      renderBoard();
      const source = elements.chessBoard.querySelector(`[data-square="${drag.from}"]`);
      const piece = source?.querySelector('.piece');
      if (!piece || !source) return;
      const rect = source.getBoundingClientRect();
      const ghost = document.createElement('span');
      ghost.className = 'drag-ghost';
      ghost.style.width = `${rect.width}px`;
      ghost.style.height = `${rect.height}px`;
      ghost.appendChild(piece.cloneNode(true));
      document.body.appendChild(ghost);
      piece.classList.add('drag-source');
      drag.ghost = ghost;
    }

    event.preventDefault();
    if (drag.ghost) drag.ghost.style.transform = `translate3d(${event.clientX - drag.ghost.offsetWidth / 2}px, ${event.clientY - drag.ghost.offsetHeight / 2}px, 0) scale(1.08)`;
    const hovered = document.elementFromPoint(event.clientX, event.clientY)?.closest('.square');
    const hoveredSquare = hovered && elements.chessBoard.contains(hovered) ? hovered.dataset.square : null;
    if (hoveredSquare !== drag.hoverSquare) {
      elements.chessBoard.querySelector('.drag-hover')?.classList.remove('drag-hover');
      drag.hoverSquare = hoveredSquare;
      if (hoveredSquare) elements.chessBoard.querySelector(`[data-square="${hoveredSquare}"]`)?.classList.add('drag-hover');
    }
  }

  function finishBoardDrag(event, cancelled = false) {
    const drag = state.drag;
    if (!drag || drag.pointerId !== event.pointerId) return;
    if (elements.chessBoard.hasPointerCapture?.(event.pointerId)) elements.chessBoard.releasePointerCapture(event.pointerId);
    drag.ghost?.remove();
    elements.chessBoard.querySelector('.drag-hover')?.classList.remove('drag-hover');
    elements.chessBoard.querySelector('.drag-source')?.classList.remove('drag-source');
    state.drag = null;

    if (!drag.active) return;
    state.suppressBoardClickUntil = Date.now() + 280;
    const targetSquare = cancelled ? null : drag.hoverSquare;
    const targetMoves = (state.game?.legalMoves || []).filter((move) => move.from === drag.from && move.to === targetSquare);
    if (!targetMoves.length) {
      state.selectedSquare = null;
      renderBoard();
      return;
    }
    if (targetMoves.some((move) => move.promotion)) openPromotion(targetMoves);
    else sendMove(drag.from, targetSquare);
  }

  function openPromotion(moves) {
    state.pendingPromotion = moves;
    elements.promotionChoices.textContent = '';
    const color = myColor() || 'white';
    const seen = new Set();
    for (const move of moves) {
      if (!move.promotion || seen.has(move.promotion)) continue;
      seen.add(move.promotion);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'promotion-choice';
      const pieceCode = color === 'white' ? move.promotion.toUpperCase() : move.promotion;
      button.appendChild(createPieceImage(pieceCode, 'promotion-piece'));
      button.setAttribute('aria-label', `${move.promotion}로 승격`);
      button.addEventListener('click', () => {
        elements.promotionOverlay.hidden = true;
        const selected = state.pendingPromotion?.find((item) => item.promotion === move.promotion);
        state.pendingPromotion = null;
        if (selected) sendMove(selected.from, selected.to, selected.promotion);
      });
      elements.promotionChoices.appendChild(button);
    }
    elements.promotionOverlay.hidden = false;
  }

  async function sendMove(from, to, promotion) {
    if (!state.game) return;
    const gameId = state.game.id;
    const optimisticSnapshot = {
      turn: state.game.turn,
      clocks: { ...(state.game.clocks || {}) },
    };
    const clocks = currentClientClocks();
    const incrementMs = Number(state.game.clocks?.incrementMs || (state.site?.incrementSeconds || 0) * 1000);
    if (state.game.turn === 'white') clocks.whiteMs += incrementMs;
    else clocks.blackMs += incrementMs;
    state.game.clocks = {
      ...clocks,
      incrementMs,
      serverNow: Date.now(),
      clientReceivedAt: clientNow(),
    };
    state.game.turn = state.game.turn === 'white' ? 'black' : 'white';
    state.selectedSquare = null;
    state.moving = true;
    showOptimisticMove(from, to, promotion);
    renderClockValues();
    renderGameStatus();
    try {
      const response = await emitAck('game:move', { gameId, from, to, promotion });
      if (response.game) handleGameState(response.game);
    } catch (error) {
      if (state.game?.id === gameId && state.moving) {
        state.game.turn = optimisticSnapshot.turn;
        state.game.clocks = optimisticSnapshot.clocks;
        renderBoard();
        renderClockValues();
      }
      state.moving = false;
      showToast(error.message, 'error');
      try {
        const response = await emitAck('game:sync', { gameId });
        handleGameState(response.game);
      } catch {
        // Reconnection handler will retry.
      }
    }
  }

  function showOptimisticMove(from, to, promotion) {
    const source = elements.chessBoard.querySelector(`[data-square="${from}"]`);
    const target = elements.chessBoard.querySelector(`[data-square="${to}"]`);
    const piece = source?.querySelector('.piece');
    if (!source || !target || !piece) {
      renderBoard();
      return;
    }
    const pieceFile = piece.getAttribute('src') || piece.src || '';
    const pieceCode = pieceFile.match(/\/([wb])([KQRBNP])\.svg(?:\?|$)/i)?.[2]?.toUpperCase();
    const targetHadPiece = Boolean(target.querySelector('.piece'));

    target.querySelector('.piece')?.remove();
    if (pieceCode === 'P' && from[0] !== to[0] && !targetHadPiece) {
      elements.chessBoard
        .querySelector(`[data-square="${to[0]}${from[1]}"] .piece`)
        ?.remove();
    }
    if (pieceCode === 'K' && Math.abs(to.charCodeAt(0) - from.charCodeAt(0)) === 2) {
      const kingSide = to[0] === 'g';
      const rookFrom = `${kingSide ? 'h' : 'a'}${from[1]}`;
      const rookTo = `${kingSide ? 'f' : 'd'}${from[1]}`;
      const rook = elements.chessBoard.querySelector(`[data-square="${rookFrom}"] .piece`);
      const rookTarget = elements.chessBoard.querySelector(`[data-square="${rookTo}"]`);
      if (rook && rookTarget) rookTarget.prepend(rook);
    }
    if (promotion) {
      const color = myColor() === 'black' ? 'b' : 'w';
      piece.src = pieceAsset(`${color === 'w' ? promotion.toUpperCase() : promotion}`);
    }
    target.prepend(piece);
    elements.chessBoard.querySelectorAll('.last-move').forEach((square) => square.classList.remove('last-move'));
    source.classList.add('last-move');
    target.classList.add('last-move');
  }

  function renderMoves() {
    const history = state.game?.history || [];
    elements.moveCount.textContent = `${history.length}수`;
    elements.moveList.textContent = '';
    if (!history.length) {
      elements.moveList.innerHTML = '<div class="no-moves">첫 수를 기다리고 있습니다.<br>중앙을 장악해 보세요.</div>';
      return;
    }

    for (let index = 0; index < history.length; index += 2) {
      const row = document.createElement('div');
      row.className = 'move-row';
      const number = document.createElement('span');
      number.className = 'move-number';
      number.textContent = `${Math.floor(index / 2) + 1}.`;
      const white = document.createElement('span');
      white.className = `move-san${index === history.length - 1 ? ' latest' : ''}`;
      white.textContent = history[index] || '';
      const black = document.createElement('span');
      black.className = `move-san${index + 1 === history.length - 1 ? ' latest' : ''}`;
      black.textContent = history[index + 1] || '';
      row.append(number, white, black);
      elements.moveList.appendChild(row);
    }
    elements.moveList.scrollTop = elements.moveList.scrollHeight;
  }

  function renderGameStatus() {
    const game = state.game;
    if (!game) return;
    const color = myColor();
    const myTurn = game.turn === color;
    const opponent = color === 'white' ? game.black : game.white;

    if (game.spectator && game.status === 'active') {
      const movingPlayer = game.turn === 'white' ? game.white : game.black;
      elements.turnStatus.textContent = '실시간 관전 중';
      elements.turnDetail.textContent = `${movingPlayer?.handle || '선수'} (${game.turn === 'white' ? '백' : '흑'})의 차례입니다.`;
    } else if (game.status === 'finished') {
      elements.turnStatus.textContent = '대국이 종료되었습니다';
      elements.turnDetail.textContent = REASON_LABELS[game.reason] || '결과를 확인해 주세요.';
    } else if (game.inCheck && myTurn) {
      elements.turnStatus.textContent = '체크! 내 차례입니다';
      elements.turnDetail.textContent = '킹을 안전한 칸으로 피하거나 공격을 막아야 합니다.';
    } else if (myTurn) {
      elements.turnStatus.textContent = '내 차례입니다';
      elements.turnDetail.textContent = `${color === 'white' ? '백' : '흑'}으로 둘 수를 선택하세요.`;
    } else {
      elements.turnStatus.textContent = '상대의 차례입니다';
      elements.turnDetail.textContent = opponent?.online === false
        ? '상대 연결이 끊겼지만 시계는 계속 흐릅니다.'
        : `${opponent?.handle || '상대'}의 수를 기다리고 있습니다.`;
    }

    const active = game.status === 'active' && !game.spectator;
    elements.offerDrawButton.disabled = !active || game.drawOffer === 'sent';
    elements.offerDrawButton.innerHTML = game.drawOffer === 'sent'
      ? '<span>½</span> 제안 전송됨'
      : '<span>½</span> 무승부 제안';
    elements.resignButton.disabled = !active;
    elements.drawOfferBox.hidden = !(active && game.drawOffer === 'received');
  }

  function startQueueOverlay() {
    state.queueing = true;
    state.queueStartedAt = Date.now();
    elements.queueOverlay.hidden = false;
    document.body.classList.add('modal-open');
    if (state.queueTimer) window.clearInterval(state.queueTimer);
    state.queueTimer = window.setInterval(() => {
      const elapsed = Math.floor((Date.now() - state.queueStartedAt) / 1000);
      elements.queueTime.textContent = `${String(Math.floor(elapsed / 60)).padStart(2, '0')}:${String(elapsed % 60).padStart(2, '0')}`;
    }, 250);
  }

  function stopQueueOverlay() {
    state.queueing = false;
    elements.queueOverlay.hidden = true;
    if (state.queueTimer) window.clearInterval(state.queueTimer);
    state.queueTimer = null;
    elements.queueTime.textContent = '00:00';
    if (elements.modalRoot.hidden && elements.promotionOverlay.hidden) document.body.classList.remove('modal-open');
  }

  async function quickMatch() {
    if (state.game?.status === 'active') {
      showToast('이미 진행 중인 대국이 있습니다.', 'info');
      return;
    }
    if (!state.me?.ratedEligible) {
      openAccountModal('rated');
      return;
    }
    try {
      const response = await emitAck('match:queue');
      if (response.activeGame) {
        handleGameState(response.activeGame);
        return;
      }
      if (response.queued) startQueueOverlay();
    } catch (error) {
      if (error.code === 'ACCOUNT_REQUIRED') {
        openAccountModal('rated');
        return;
      }
      showToast(error.message, 'error');
    }
  }

  async function cancelQueue() {
    try {
      await emitAck('match:cancel');
    } catch {
      // Local overlay should still close.
    }
    stopQueueOverlay();
  }

  function openModal(content, { onClose = null, locked = false } = {}) {
    elements.modalContent.innerHTML = content;
    state.modalOnClose = onClose;
    state.modalLocked = locked;
    elements.modalCloseButton.hidden = locked;
    elements.modalRoot.hidden = false;
    document.body.classList.add('modal-open');
  }

  function closeModal(force = false) {
    if (elements.modalRoot.hidden) return;
    if (state.modalLocked && !force) return;
    const onClose = state.modalOnClose;
    state.modalOnClose = null;
    state.modalLocked = false;
    elements.modalRoot.hidden = true;
    elements.modalContent.textContent = '';
    elements.modalCloseButton.hidden = false;
    if (!force && typeof onClose === 'function') onClose();
    if (elements.queueOverlay.hidden && elements.promotionOverlay.hidden) document.body.classList.remove('modal-open');
  }

  async function resumePendingInvite() {
    if (!state.connected || !state.me?.ratedEligible || state.game) return;
    let code = '';
    try {
      code = sessionStorage.getItem('nova_pending_invite') || '';
      if (code) sessionStorage.removeItem('nova_pending_invite');
    } catch {
      return;
    }
    if (!code) return;
    try {
      await emitAck('invite:join', { code });
    } catch (error) {
      showToast(error.message, 'error');
    }
  }

  function registrationForm() {
    const suggestedHandle = state.me?.isGuest ? '' : state.me?.handle || '';
    return `
      <form id="registerAccountForm" class="form-stack">
        <label class="field-label">아이디<input name="handle" autocomplete="username" minlength="3" maxlength="20" value="${escapeHtml(suggestedHandle)}" placeholder="예: chess_master" required></label>
        <label class="field-label">이메일<input name="email" type="email" autocomplete="email" maxlength="120" placeholder="name@example.com" required></label>
        <label class="field-label">비밀번호<input name="password" type="password" autocomplete="new-password" minlength="8" maxlength="128" placeholder="8자 이상" required></label>
        <label class="field-label">비밀번호 확인<input name="passwordConfirm" type="password" autocomplete="new-password" minlength="8" maxlength="128" placeholder="비밀번호 다시 입력" required></label>
        <button class="submit-button" type="submit">무료 계정 만들기</button>
        <p class="form-note">현재 ${formatNumber(state.me?.rating)} RP와 대국 기록은 그대로 유지됩니다. 비밀번호는 scrypt로 암호화해 저장합니다.</p>
      </form>
    `;
  }

  function loginForm() {
    return `
      <form id="loginForm" class="form-stack">
        <label class="field-label">아이디 또는 이메일<input name="identity" autocomplete="username" maxlength="120" placeholder="아이디 또는 이메일" required></label>
        <label class="field-label">비밀번호<input name="password" type="password" autocomplete="current-password" minlength="8" maxlength="128" placeholder="비밀번호" required></label>
        <button class="submit-button" type="submit">기존 계정으로 로그인</button>
        <p class="form-note">로그인하면 현재 게스트 세션 대신 기존 계정이 열립니다.</p>
      </form>
    `;
  }

  function openAccountModal(context = 'account') {
    if (!state.me) return;
    if (state.me.ratedEligible) {
      openModal(`
        <div class="modal-body">
          <span class="section-kicker">MEMBER ACCOUNT</span>
          <h2>내 계정</h2>
          <p class="modal-description">회원 계정으로 레이팅 대국과 순위표를 이용하고 있습니다.</p>
          <div class="account-summary member-account-summary">
            <span class="avatar avatar-large">${escapeHtml(initial(state.me.handle))}</span>
            <div class="account-summary-copy"><strong>${escapeHtml(state.me.handle)}</strong><span>${formatNumber(state.me.rating)} RP · ${state.me.gamesPlayed}경기</span><small>로그인 계정</small></div>
          </div>
          <div class="account-ready-row"><i>✓</i><span>레이팅 대국 참여 가능</span></div>
          <button id="logoutButton" class="danger-button" type="button">로그아웃</button>
        </div>
      `);
      $('logoutButton').addEventListener('click', async () => {
        try {
          await api('/api/auth/logout', { method: 'POST' });
          window.location.reload();
        } catch (error) {
          showToast(error.message, 'error');
        }
      });
      return;
    }

    const title = context === 'rated' ? '레이팅 대전을 시작하려면' : '계정 만들기 또는 로그인';
    openModal(`
      <div class="modal-body account-auth-body">
        <span class="section-kicker">MEMBER RATING</span>
        <h2>${title}</h2>
        <p class="modal-description">아이디·이메일·비밀번호로 가입하면 현재 기록이 계정에 저장되고, 다른 기기에서도 로그인할 수 있습니다.</p>
        <div class="tabs" role="tablist" aria-label="계정 메뉴">
          <button id="registerTabButton" class="tab-button active" type="button" role="tab" aria-selected="true">계정 만들기</button>
          <button id="loginTabButton" class="tab-button" type="button" role="tab" aria-selected="false">로그인</button>
        </div>
        <div id="authFormSlot" class="auth-form-slot"></div>
      </div>
    `);

    const showAuthTab = (mode) => {
      const isRegister = mode === 'register';
      $('registerTabButton').classList.toggle('active', isRegister);
      $('loginTabButton').classList.toggle('active', !isRegister);
      $('registerTabButton').setAttribute('aria-selected', String(isRegister));
      $('loginTabButton').setAttribute('aria-selected', String(!isRegister));
      $('authFormSlot').innerHTML = isRegister ? registrationForm() : loginForm();
      if (isRegister) bindRegistrationForm();
      else bindLoginForm();
    };
    $('registerTabButton').addEventListener('click', () => showAuthTab('register'));
    $('loginTabButton').addEventListener('click', () => showAuthTab('login'));
    showAuthTab('register');
  }

  function bindRegistrationForm() {
    const form = $('registerAccountForm');
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      const formData = new FormData(form);
      if (formData.get('password') !== formData.get('passwordConfirm')) {
        showToast('비밀번호 확인이 일치하지 않습니다.', 'error');
        return;
      }
      button.disabled = true;
      button.textContent = '계정 만드는 중…';
      try {
        await api('/api/auth/register', {
          method: 'POST',
          body: {
            handle: formData.get('handle'),
            email: formData.get('email'),
            password: formData.get('password'),
          },
        });
        showToast('계정이 만들어졌습니다. 이제 레이팅 대국에 참여할 수 있습니다.');
        window.setTimeout(() => window.location.reload(), 350);
      } catch (error) {
        button.disabled = false;
        button.textContent = '무료 계정 만들기';
        showToast(error.message, 'error');
      }
    });
  }

  function bindLoginForm() {
    const form = $('loginForm');
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      const formData = new FormData(form);
      button.disabled = true;
      button.textContent = '로그인 중…';
      try {
        await api('/api/auth/login', {
          method: 'POST',
          body: {
            identity: formData.get('identity'),
            password: formData.get('password'),
          },
        });
        showToast('로그인되었습니다.');
        window.setTimeout(() => window.location.reload(), 350);
      } catch (error) {
        button.disabled = false;
        button.textContent = '기존 계정으로 로그인';
        showToast(error.message, 'error');
      }
    });
  }

  function openSpectateModal() {
    openModal(`
      <div class="modal-body">
        <span class="section-kicker">LIVE SPECTATE</span>
        <h2>닉네임으로 경기 관전</h2>
        <p class="modal-description">진행 중인 사용자의 정확한 닉네임을 입력하세요. 관전자는 수를 두거나 채팅할 수 없습니다.</p>
        <form id="spectateForm" class="form-stack">
          <label class="field-label">닉네임<input id="spectateHandleInput" name="handle" minlength="3" maxlength="20" autocomplete="off" placeholder="예: chess_master" required></label>
          <button class="submit-button" type="submit">진행 중인 경기 찾기</button>
        </form>
      </div>
    `);

    $('spectateForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const handle = $('spectateHandleInput').value.trim();
      const button = event.currentTarget.querySelector('button');
      button.disabled = true;
      button.textContent = '검색 중…';
      try {
        const data = await api(`/api/spectate?handle=${encodeURIComponent(handle)}`);
        if (!data.game) throw new Error('현재 진행 중인 경기가 없습니다.');
        state.spectatingHandle = data.player?.handle || handle;
        state.spectatorSyncRunning = true;
        closeModal(true);
        handleGameState(data.game);
        spectatorSyncLoop();
      } catch (error) {
        button.disabled = false;
        button.textContent = '진행 중인 경기 찾기';
        showToast(error.message, 'error');
      }
    });
  }

  async function spectatorSyncLoop() {
    if (!state.spectatorSyncRunning || !state.spectatingHandle) return;
    const handle = state.spectatingHandle;
    try {
      const data = await api(`/api/spectate?handle=${encodeURIComponent(handle)}&wait=1`);
      if (!state.spectatorSyncRunning || state.spectatingHandle !== handle) return;
      if (!data.game) {
        stopSpectating();
        state.game = null;
        showToast('관전하던 대국이 종료되었습니다.', 'info');
        renderAll();
        return;
      }
      handleGameState(data.game);
    } catch (error) {
      if (state.spectatorSyncRunning) showToast(error.message, 'error');
    }
    if (state.spectatorSyncRunning) window.setTimeout(spectatorSyncLoop, 50);
  }

  function stopSpectating() {
    state.spectatorSyncRunning = false;
    state.spectatingHandle = '';
  }

  function openInviteModal() {
    const canPlayRated = Boolean(state.me?.ratedEligible);
    openModal(`
      <div class="modal-body">
        <span class="section-kicker">PLAY WITH A FRIEND</span>
        <h2>친구와 온라인 대전</h2>
        <p class="modal-description">초대 코드를 만들거나 친구에게 받은 6자리 코드를 입력하세요.</p>
        <div class="invite-options">
          <div class="invite-option-card">
            <h3>새 초대 만들기</h3>
            <p>코드를 공유하면 친구가 같은 VPS 서버에서 바로 입장할 수 있습니다.</p>
            <div class="toggle-row"><span>레이팅 반영</span><label class="toggle"><input id="inviteRatedToggle" type="checkbox" ${canPlayRated ? 'checked' : 'disabled'}><span></span></label></div>
            ${canPlayRated ? '' : '<p class="rated-lock-note"><i>✓</i> 회원가입 전에는 일반 대전으로 생성됩니다.</p><button id="inviteAccountButton" class="account-inline-login" type="button">계정 만들기·로그인</button>'}
            <button id="createInviteButton" class="submit-button full-submit" type="button">초대 코드 만들기</button>
          </div>
          <div class="invite-option-card">
            <h3>초대 코드로 참가</h3>
            <p>친구에게 받은 코드를 입력하면 즉시 대국이 시작됩니다.</p>
            <form id="joinInviteForm" class="form-stack no-top-margin">
              <input id="inviteCodeInput" class="code-input" name="code" maxlength="6" autocomplete="off" placeholder="예: A7K9PX" required>
              <button class="submit-button" type="submit">대국 참가</button>
            </form>
          </div>
        </div>
      </div>
    `);

    $('inviteAccountButton')?.addEventListener('click', () => openAccountModal('rated'));

    $('createInviteButton').addEventListener('click', async () => {
      const button = $('createInviteButton');
      button.disabled = true;
      button.textContent = '코드 생성 중…';
      try {
        const response = await emitAck('invite:create', { rated: $('inviteRatedToggle').checked });
        showInviteCode(response);
      } catch (error) {
        if (error.code === 'ACCOUNT_REQUIRED') {
          openAccountModal('rated');
          return;
        }
        button.disabled = false;
        button.textContent = '초대 코드 만들기';
        showToast(error.message, 'error');
      }
    });

    $('inviteCodeInput').addEventListener('input', (event) => {
      event.target.value = event.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 6);
    });

    $('joinInviteForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const button = form.querySelector('button');
      const code = $('inviteCodeInput').value.trim().toUpperCase();
      button.disabled = true;
      button.textContent = '입장 중…';
      try {
        await emitAck('invite:join', { code });
      } catch (error) {
        if (error.code === 'ACCOUNT_REQUIRED') {
          try {
            sessionStorage.setItem('nova_pending_invite', code);
          } catch {
            // The user can enter the code again after login.
          }
          openAccountModal('rated');
          return;
        }
        button.disabled = false;
        button.textContent = '대국 참가';
        showToast(error.message, 'error');
      }
    });
  }

  function showInviteCode(invite) {
    state.inviteCode = invite.code;
    state.modalOnClose = () => {
      emitAck('invite:cancel').catch(() => {});
      state.inviteCode = null;
    };
    elements.modalContent.innerHTML = `
      <div class="modal-body">
        <span class="section-kicker">INVITE READY</span>
        <h2>친구를 기다리고 있습니다</h2>
        <p class="modal-description">아래 코드를 친구에게 보내세요. 친구가 입력하면 자동으로 대국 화면으로 이동합니다.</p>
        <div class="invite-code-display"><small>INVITE CODE · ${invite.rated ? 'RATED' : 'UNRATED'}</small><strong>${escapeHtml(invite.code)}</strong></div>
        <button id="copyInviteButton" class="copy-button" type="button">초대 코드 복사</button>
        <p class="waiting-note"><i class="live-dot"></i> 상대 접속 대기 중</p>
      </div>
    `;
    $('copyInviteButton').addEventListener('click', () => copyText(invite.code));
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      showToast('초대 코드를 복사했습니다.');
    } catch {
      const input = document.createElement('textarea');
      input.value = text;
      input.className = 'clipboard-helper';
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      input.remove();
      showToast('초대 코드를 복사했습니다.');
    }
  }

  function openConfirm({ title, description, confirmLabel, danger = false, onConfirm }) {
    openModal(`
      <div class="modal-body">
        <span class="section-kicker">CONFIRM</span>
        <h2>${escapeHtml(title)}</h2>
        <p class="modal-description">${escapeHtml(description)}</p>
        <div class="confirm-actions">
          <button id="confirmCancelButton" class="confirm-cancel" type="button">취소</button>
          <button id="confirmActionButton" class="${danger ? 'confirm-danger' : 'submit-button'}" type="button">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>
    `);
    $('confirmCancelButton').addEventListener('click', () => closeModal());
    $('confirmActionButton').addEventListener('click', async () => {
      const button = $('confirmActionButton');
      button.disabled = true;
      try {
        await onConfirm();
        closeModal(true);
      } catch (error) {
        button.disabled = false;
        showToast(error.message, 'error');
      }
    });
  }

  function openResultModal(finished) {
    const isDraw = finished.winnerUserId === null;
    const isWin = finished.winnerUserId === state.me.id;
    const mine = finished.white.id === state.me.id ? finished.white : finished.black;
    const title = isDraw ? '무승부입니다' : isWin ? '승리했습니다' : '패배했습니다';
    const icon = isDraw ? 'bR' : isWin ? 'wQ' : 'bP';
    const delta = Number(mine.ratingDelta || 0);
    const deltaClass = delta > 0 ? '' : delta < 0 ? 'negative' : 'neutral';
    const reason = REASON_LABELS[finished.reason] || '대국 종료';

    const leaveResult = () => {
      state.game = null;
      state.finishedGame = null;
      state.selectedSquare = null;
      renderAll();
    };

    openModal(`
      <div class="result-hero">
        <div class="result-icon"><img src="/pieces/nova/${icon}.svg" alt="" draggable="false"></div>
        <h2>${title}</h2>
        <p>${escapeHtml(reason)} · ${escapeHtml(finished.result || '')}</p>
        <div class="result-rating"><strong>${formatNumber(mine.ratingAfter)}</strong><span class="${deltaClass}">${finished.rated ? `${delta > 0 ? '+' : ''}${delta} RP` : 'UNRATED'}</span></div>
        <p>${finished.rated ? '새 레이팅이 프로필과 순위표에 반영되었습니다.' : '일반 대전은 레이팅에 반영되지 않습니다.'}</p>
        <div class="result-actions">
          <button id="resultHomeButton" class="result-home" type="button">로비로</button>
          <button id="resultNextButton" class="result-rematch" type="button">다음 상대 찾기</button>
        </div>
      </div>
    `, { onClose: leaveResult });

    $('resultHomeButton').addEventListener('click', () => {
      closeModal(true);
      leaveResult();
    });
    $('resultNextButton').addEventListener('click', () => {
      closeModal(true);
      leaveResult();
      quickMatch();
    });
  }

  async function refreshLeaderboard() {
    elements.refreshLeaderboardButton.disabled = true;
    try {
      const data = await api('/api/leaderboard');
      state.leaderboard = data.leaderboard || [];
      renderLeaderboard();
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      elements.refreshLeaderboardButton.disabled = false;
    }
  }

  elements.quickMatchButton.addEventListener('click', quickMatch);
  elements.cancelQueueButton.addEventListener('click', cancelQueue);
  elements.openInviteButton.addEventListener('click', openInviteModal);
  elements.openSpectateButton.addEventListener('click', openSpectateModal);
  elements.accountButton.addEventListener('click', () => openAccountModal('account'));
  elements.profileAccountAction.addEventListener('click', () => openAccountModal('profile'));
  elements.refreshLeaderboardButton.addEventListener('click', refreshLeaderboard);
  elements.modalCloseButton.addEventListener('click', () => closeModal());
  elements.modalBackdrop.addEventListener('click', () => closeModal());
  elements.chessBoard.addEventListener('pointerdown', boardPointerDown);
  elements.chessBoard.addEventListener('pointermove', boardPointerMove);
  elements.chessBoard.addEventListener('pointerup', (event) => finishBoardDrag(event));
  elements.chessBoard.addEventListener('pointercancel', (event) => finishBoardDrag(event, true));

  elements.brandButton.addEventListener('click', () => {
    if (state.game?.status === 'active' && !state.game.spectator) {
      showToast('대국이 끝난 뒤 로비로 이동할 수 있습니다.', 'info');
      return;
    }
    stopSpectating();
    state.game = null;
    renderAll();
  });

  elements.offerDrawButton.addEventListener('click', async () => {
    if (!state.game) return;
    try {
      await emitAck('game:draw-offer', { gameId: state.game.id });
      showToast(state.game.drawOffer === 'received' ? '무승부 제안을 수락했습니다.' : '무승부를 제안했습니다.', 'info');
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  elements.acceptDrawButton.addEventListener('click', async () => {
    if (!state.game) return;
    try {
      await emitAck('game:draw-offer', { gameId: state.game.id });
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  elements.declineDrawButton.addEventListener('click', async () => {
    if (!state.game) return;
    try {
      await emitAck('game:draw-decline', { gameId: state.game.id });
      showToast('무승부 제안을 거절했습니다.', 'info');
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  elements.resignButton.addEventListener('click', () => {
    if (!state.game) return;
    openConfirm({
      title: '정말 기권할까요?',
      description: state.game.rated ? '기권하면 패배로 기록되고 레이팅이 반영됩니다.' : '기권하면 패배로 기록됩니다.',
      confirmLabel: '기권하기',
      danger: true,
      onConfirm: () => emitAck('game:resign', { gameId: state.game.id }),
    });
  });

  elements.chatForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!state.game || state.game.status !== 'active' || state.game.spectator) return;
    const message = elements.chatInput.value.trim();
    if (!message) return;
    elements.chatSendButton.disabled = true;
    try {
      await emitAck('game:chat', { gameId: state.game.id, message });
      elements.chatInput.value = '';
      elements.chatInput.focus();
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      elements.chatSendButton.disabled = false;
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (!elements.promotionOverlay.hidden) return;
    if (!elements.queueOverlay.hidden) {
      cancelQueue();
      return;
    }
    closeModal();
  });

  window.addEventListener('beforeunload', () => {
    if (state.inviteCode) state.socket?.emit('invite:cancel');
  });

  elements.currentYear.textContent = String(new Date().getFullYear());
  loadBootstrap();
})();
