const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { io: createClient } = require('socket.io-client');
const { buildApplication } = require('../src/app');

function once(socket, event, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      socket.off(event, handler);
      reject(new Error(`Timed out waiting for ${event}`));
    }, timeoutMs);
    const handler = (payload) => {
      clearTimeout(timeout);
      resolve(payload);
    };
    socket.once(event, handler);
  });
}

function emitAck(socket, event, payload = {}, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`Timed out waiting for ack: ${event}`)), timeoutMs);
    socket.emit(event, payload, (response) => {
      clearTimeout(timeout);
      if (!response?.ok) {
        reject(new Error(`${response?.code || 'ERROR'}: ${response?.message || 'unknown error'}`));
        return;
      }
      resolve(response);
    });
  });
}

function cookieFrom(response) {
  const raw = response.headers.get('set-cookie');
  assert.ok(raw, 'session cookie should be set');
  return raw.split(';')[0];
}

async function bootstrap(baseUrl, cookie) {
  const response = await fetch(`${baseUrl}/api/bootstrap`, {
    headers: cookie ? { Cookie: cookie } : {},
  });
  assert.equal(response.status, 200);
  return { cookie: cookie || cookieFrom(response), data: await response.json() };
}

function connect(baseUrl, cookie) {
  return new Promise((resolve, reject) => {
    const socket = createClient(baseUrl, {
      transports: ['websocket'],
      extraHeaders: { Cookie: cookie },
      reconnection: false,
      forceNew: true,
    });
    socket.once('connect', () => resolve(socket));
    socket.once('connect_error', reject);
  });
}

function postJson(baseUrl, pathName, cookie, body) {
  return fetch(`${baseUrl}${pathName}`, {
    method: 'POST',
    headers: {
      ...(cookie ? { Cookie: cookie } : {}),
      Origin: baseUrl,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body || {}),
  });
}

test('local account registration, login, matchmaking, legal play, and Elo update', async (t) => {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-chess-test-'));
  const config = {
    host: '127.0.0.1',
    port: 0,
    nodeEnv: 'test',
    dataDir,
    trustProxy: 0,
    cookieSecure: true,
    sessionDays: 30,
    initialRating: 100,
    eloK: 32,
    ratingFloor: 0,
    gameMinutes: 10,
    gameIncrementSeconds: 3,
    inviteTtlMinutes: 30,
    siteName: 'NOVA CHESS TEST',
    gasBridgeSecret: 'test-gas-bridge-secret-123456789',
  };

  const application = buildApplication(config);
  await new Promise((resolve) => application.server.listen(0, '127.0.0.1', resolve));
  const port = application.server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;
  const sockets = [];

  t.after(async () => {
    for (const socket of sockets) socket.close();
    await application.close();
    fs.rmSync(dataDir, { recursive: true, force: true });
  });

  const sessionA = await bootstrap(baseUrl);
  const sessionB = await bootstrap(baseUrl);
  assert.equal(sessionA.data.me.rating, 100);
  assert.equal(sessionB.data.me.rating, 100);
  assert.equal(sessionA.data.me.isGuest, true);

  const framedPage = await fetch(`${baseUrl}/`);
  assert.equal(framedPage.headers.get('x-frame-options'), null);
  assert.match(framedPage.headers.get('content-security-policy'), /frame-ancestors[^;]*https:\/\/script\.google\.com/);
  const embeddedCookieResponse = await fetch(`${baseUrl}/api/bootstrap`);
  const embeddedCookie = embeddedCookieResponse.headers.get('set-cookie') || '';
  assert.match(embeddedCookie, /SameSite=None/i);
  assert.match(embeddedCookie, /Secure/i);
  assert.match(embeddedCookie, /Partitioned/i);

  const rejectedBridge = await postJson(baseUrl, '/api/gas/state', sessionA.cookie, {});
  assert.equal(rejectedBridge.status, 403);

  const bridgeState = await fetch(`${baseUrl}/api/gas/state`, {
    method: 'POST',
    headers: {
      Cookie: sessionA.cookie,
      Origin: baseUrl,
      'X-GAS-Bridge': config.gasBridgeSecret,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({}),
  });
  assert.equal(bridgeState.status, 200);
  assert.equal((await bridgeState.json()).ok, true);

  const guestBridgeAction = await fetch(`${baseUrl}/api/gas/action`, {
    method: 'POST',
    headers: {
      Cookie: sessionA.cookie,
      'X-GAS-Bridge': config.gasBridgeSecret,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ event: 'match:queue', payload: {} }),
  });
  assert.equal(guestBridgeAction.status, 400);
  assert.equal((await guestBridgeAction.json()).code, 'ACCOUNT_REQUIRED');

  const guestSocket = await connect(baseUrl, sessionA.cookie);
  await assert.rejects(emitAck(guestSocket, 'match:queue'), /ACCOUNT_REQUIRED/);
  guestSocket.close();

  const accountSessions = [];
  for (const [session, suffix] of [[sessionA, 'a'], [sessionB, 'b']]) {
    const response = await postJson(baseUrl, '/api/auth/register', session.cookie, {
      handle: `player_${suffix}`,
      email: `player_${suffix}@example.com`,
      password: `safe-password-${suffix}`,
    });
    assert.equal(response.status, 200);
    const data = await response.json();
    assert.equal(data.me.isAccount, true);
    assert.equal(data.me.ratedEligible, true);
    const stored = application.db.getUserById(data.me.id);
    assert.notEqual(stored.password_hash, `safe-password-${suffix}`);
    assert.match(stored.password_hash, /^scrypt\$/);
    accountSessions.push({ cookie: cookieFrom(response), data });
  }

  const [accountA, accountB] = accountSessions;
  const memberA = await bootstrap(baseUrl, accountA.cookie);
  const memberB = await bootstrap(baseUrl, accountB.cookie);
  assert.equal(memberA.data.me.ratedEligible, true);
  assert.equal(memberB.data.me.ratedEligible, true);

  const socketA = await connect(baseUrl, accountA.cookie);
  const socketB = await connect(baseUrl, accountB.cookie);
  sockets.push(socketA, socketB);

  const gameAStarted = once(socketA, 'game:started');
  const gameBStarted = once(socketB, 'game:started');
  const queued = await emitAck(socketA, 'match:queue');
  assert.equal(queued.queued, true);
  const matched = await emitAck(socketB, 'match:queue');
  assert.equal(matched.matched, true);

  const [gameA, gameB] = await Promise.all([gameAStarted, gameBStarted]);
  assert.equal(gameA.id, gameB.id);
  assert.notEqual(gameA.color, gameB.color);

  const spectatorSession = await bootstrap(baseUrl);
  const spectateResponse = await fetch(`${baseUrl}/api/spectate?handle=player_a`, {
    headers: { Cookie: spectatorSession.cookie },
  });
  assert.equal(spectateResponse.status, 200);
  const spectateState = await spectateResponse.json();
  assert.equal(spectateState.game.id, gameA.id);
  assert.equal(spectateState.game.spectator, true);
  assert.deepEqual(spectateState.game.legalMoves, []);
  assert.deepEqual(spectateState.game.chat, []);

  const gasHeaders = {
    Cookie: accountA.cookie,
    Origin: baseUrl,
    'X-GAS-Bridge': config.gasBridgeSecret,
    'Content-Type': 'application/json',
  };
  const primeState = await fetch(`${baseUrl}/api/gas/state`, {
    method: 'POST',
    headers: gasHeaders,
    body: JSON.stringify({ lastGameId: gameA.id }),
  });
  assert.equal(primeState.status, 200);

  const chatStatePromise = once(socketB, 'game:state');
  const longPollStartedAt = Date.now();
  const changedStatePromise = fetch(`${baseUrl}/api/gas/state`, {
    method: 'POST',
    headers: gasHeaders,
    body: JSON.stringify({ lastGameId: gameA.id }),
  });
  await new Promise((resolve) => setTimeout(resolve, 30));
  await emitAck(socketA, 'game:chat', { gameId: gameA.id, message: '좋은 경기 부탁해요!' });
  const [chatState, changedStateResponse] = await Promise.all([chatStatePromise, changedStatePromise]);
  assert.equal(chatState.chat.at(-1).message, '좋은 경기 부탁해요!');
  assert.ok(Date.now() - longPollStartedAt < 2000, 'state long poll should resolve immediately on a game event');
  const changedState = await changedStateResponse.json();
  assert.equal(changedState.game.chat.at(-1).message, '좋은 경기 부탁해요!');

  const whiteSocket = gameA.color === 'white' ? socketA : socketB;
  const blackSocket = gameA.color === 'black' ? socketA : socketB;
  const whiteSession = gameA.color === 'white' ? accountA : accountB;
  const blackSession = gameA.color === 'black' ? accountA : accountB;
  const finishedPromise = once(whiteSocket, 'game:finished');

  const firstMove = await emitAck(whiteSocket, 'game:move', { gameId: gameA.id, from: 'f2', to: 'f3' });
  assert.equal(firstMove.game.clocks.incrementMs, 3000);
  assert.ok(firstMove.game.clocks.whiteMs > 601_000, 'white clock should receive the 3 second increment');
  await emitAck(blackSocket, 'game:move', { gameId: gameA.id, from: 'e7', to: 'e5' });
  await emitAck(whiteSocket, 'game:move', { gameId: gameA.id, from: 'g2', to: 'g4' });
  await emitAck(blackSocket, 'game:move', { gameId: gameA.id, from: 'd8', to: 'h4' });

  const finished = await finishedPromise;
  assert.equal(finished.reason, 'checkmate');
  assert.equal(finished.result, '0-1');
  assert.equal(finished.black.ratingAfter, 116);
  assert.equal(finished.white.ratingAfter, 84);

  const whiteAfter = await bootstrap(baseUrl, whiteSession.cookie);
  const blackAfter = await bootstrap(baseUrl, blackSession.cookie);
  assert.equal(whiteAfter.data.me.rating, 84);
  assert.equal(blackAfter.data.me.rating, 116);
  assert.equal(blackAfter.data.me.wins, 1);
  assert.equal(whiteAfter.data.me.losses, 1);

  const leaderboard = await fetch(`${baseUrl}/api/leaderboard`, { headers: { Cookie: blackSession.cookie } }).then((response) => response.json());
  assert.equal(leaderboard.leaderboard.length, 2);
  assert.ok(leaderboard.leaderboard.every((player) => player.ratedEligible));

  const blackHandle = gameA.color === 'black' ? 'player_a' : 'player_b';
  const blackPassword = gameA.color === 'black' ? 'safe-password-a' : 'safe-password-b';
  const logoutResponse = await postJson(baseUrl, '/api/auth/logout', blackSession.cookie);
  assert.equal(logoutResponse.status, 200);
  const loginResponse = await postJson(baseUrl, '/api/auth/login', null, {
    identity: blackHandle,
    password: blackPassword,
  });
  assert.equal(loginResponse.status, 200);
  const loggedIn = await bootstrap(baseUrl, cookieFrom(loginResponse));
  assert.equal(loggedIn.data.me.handle, blackHandle);
  assert.equal(loggedIn.data.me.rating, 116);
});
