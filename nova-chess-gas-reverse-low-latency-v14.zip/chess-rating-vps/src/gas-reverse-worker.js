const { setTimeout: delay } = require('node:timers/promises');

function extractSessionToken(setCookie) {
  if (setCookie === undefined || setCookie === null) return null;
  const match = String(setCookie).match(/(?:^|[,\s])nova_chess_session=([^;]*)/i);
  if (!match) return null;
  if (!match[1]) return '';
  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
}

function createGasReverseWorker({ config, logger = console, fetchImpl = fetch }) {
  if (!config.gasReverseUrl || !config.gasReverseSecret) return null;

  let stopped = false;
  let loopPromise = null;
  let resultTimer = null;
  let flushing = false;
  const pendingResults = [];
  const activeRequests = new Set();
  const controller = new AbortController();
  const localBaseUrl = `http://127.0.0.1:${config.port}`;

  async function postToGas(payload) {
    const response = await fetchImpl(config.gasReverseUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ ...payload, secret: config.gasReverseSecret }),
      redirect: 'follow',
      signal: controller.signal,
    });
    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text || '{}');
    } catch {
      throw new Error(`Apps Script가 JSON이 아닌 응답을 보냈습니다. 배포 URL을 확인하세요. HTTP ${response.status}`);
    }
    if (!response.ok || data.ok === false) {
      throw new Error(data.message || `Apps Script 역방향 브리지 HTTP ${response.status}`);
    }
    return data;
  }

  async function processRequest(request) {
    const token = String(request.token || '').slice(0, 300);
    let path;
    let method;
    let body;
    let gasOnly = false;

    if (request.kind === 'api') {
      path = String(request.path || '');
      method = String(request.method || 'GET').toUpperCase();
      body = request.body;
      if (!path.startsWith('/api/')) throw new Error('허용되지 않는 API 경로입니다.');
    } else if (request.kind === 'state') {
      path = '/api/gas/state';
      method = 'POST';
      body = request.body || {};
      gasOnly = true;
    } else if (request.kind === 'action') {
      path = '/api/gas/action';
      method = 'POST';
      body = { event: String(request.eventName || ''), payload: request.body || {} };
      gasOnly = true;
    } else {
      throw new Error('지원하지 않는 역방향 요청입니다.');
    }

    const headers = { Accept: 'application/json' };
    if (token) headers.Cookie = `nova_chess_session=${encodeURIComponent(token)}`;
    if (gasOnly) headers['X-GAS-Bridge'] = config.gasBridgeSecret;
    const options = { method, headers, signal: controller.signal };
    if (!['GET', 'HEAD'].includes(method)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body ?? {});
    }

    const target = new URL(path, localBaseUrl);
    if (target.origin !== localBaseUrl || !target.pathname.startsWith('/api/')) {
      throw new Error('로컬 API 경로 검증에 실패했습니다.');
    }
    const response = await fetchImpl(target, options);
    let data;
    try {
      data = await response.json();
    } catch {
      data = { ok: false, code: 'INVALID_LOCAL_RESPONSE', message: 'VPS API 응답을 읽지 못했습니다.' };
    }
    const changedToken = extractSessionToken(response.headers.get('set-cookie'));
    return {
      ok: response.ok && data.ok !== false,
      status: response.status,
      data,
      bridgeToken: changedToken === null ? token : changedToken,
    };
  }

  function queueResult(item) {
    pendingResults.push(item);
    if (resultTimer || flushing || stopped) return;
    resultTimer = setTimeout(() => {
      resultTimer = null;
      flushResults().catch((error) => {
        if (!stopped) logger.error('GAS reverse result flush failed:', error.message);
      });
    }, 0);
    resultTimer.unref?.();
  }

  async function flushResults() {
    if (flushing || stopped || pendingResults.length === 0) return;
    flushing = true;
    const batch = pendingResults.splice(0, 50);
    let retryDelayMs = 0;
    try {
      await postToGas({ op: 'push', results: batch });
    } catch (error) {
      pendingResults.unshift(...batch);
      retryDelayMs = 250;
      throw error;
    } finally {
      flushing = false;
      if (!stopped && pendingResults.length) {
        if (retryDelayMs) {
          await delay(retryDelayMs, undefined, { signal: controller.signal }).catch(() => {});
        }
        if (!stopped) flushResults().catch((error) => logger.error('GAS reverse result retry failed:', error.message));
      }
    }
  }

  function dispatch(request) {
    if (!request?.id || activeRequests.size >= 200) {
      if (request?.id) queueResult({
        id: request.id,
        result: { ok: false, status: 503, data: { ok: false, code: 'REVERSE_BUSY', message: 'VPS 브리지가 혼잡합니다.' }, bridgeToken: String(request.token || '') },
      });
      return;
    }
    const task = processRequest(request)
      .then((result) => queueResult({ id: request.id, result }))
      .catch((error) => {
        if (stopped && error.name === 'AbortError') return;
        queueResult({
          id: request.id,
          result: {
            ok: false,
            status: 502,
            data: { ok: false, code: 'REVERSE_VPS_ERROR', message: error.message },
            bridgeToken: String(request.token || ''),
          },
        });
      })
      .finally(() => activeRequests.delete(task));
    activeRequests.add(task);
  }

  async function loop() {
    let backoffMs = 500;
    while (!stopped) {
      try {
        const data = await postToGas({ op: 'pull' });
        backoffMs = 500;
        for (const request of data.requests || []) dispatch(request);
      } catch (error) {
        if (stopped || error.name === 'AbortError') break;
        logger.error('GAS reverse pull failed:', error.message);
        await delay(backoffMs, undefined, { signal: controller.signal }).catch(() => {});
        backoffMs = Math.min(10_000, backoffMs * 2);
      }
    }
  }

  return {
    start() {
      if (!loopPromise) {
        logger.log('GAS reverse bridge enabled: VPS outbound polling started');
        loopPromise = loop();
      }
      return loopPromise;
    },
    async stop() {
      if (stopped) return;
      stopped = true;
      if (resultTimer) clearTimeout(resultTimer);
      controller.abort();
      await Promise.allSettled([...activeRequests]);
      await loopPromise?.catch(() => {});
    },
  };
}

module.exports = { createGasReverseWorker, extractSessionToken };
