const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');
const pieces = ['wK', 'wQ', 'wR', 'wB', 'wN', 'wP', 'bK', 'bQ', 'bR', 'bB', 'bN', 'bP'];

let html = read('public/index.html');
const css = read('public/styles.css');
let app = read('public/app.js');
const client = read('gas/reverse-client.js');
const server = read('gas/reverse-server.gs');
const pieceMap = {};

for (const name of pieces) {
  const svg = read(`public/pieces/nova/${name}.svg`);
  pieceMap[name] = `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
}

html = html
  .replace(/<link[^>]+rel=["']stylesheet["'][^>]*>/i, `<style>${css}</style>`)
  .replace(/<link[^>]+rel=["']manifest["'][^>]*>/gi, '')
  .replace(/<link[^>]+rel=["']icon["'][^>]*>/gi, '')
  .replace(/<script[^>]+socket\.io[^>]*><\/script>/gi, '')
  .replace(/<script[^>]+\/app\.js[^>]*><\/script>/gi, '');

for (const name of pieces) {
  html = html.split(`/pieces/nova/${name}.svg`).join(pieceMap[name]);
  app = app.split(`/pieces/nova/${name}.svg`).join(pieceMap[name]);
}

app = app.replace(
  "return `/pieces/nova/${white ? 'w' : 'b'}${pieceCode.toUpperCase()}.svg`;",
  "return window.NOVA_PIECES[(white ? 'w' : 'b') + pieceCode.toUpperCase()];",
);

const escapeScript = (value) => value.replace(/<\/script/gi, '<\\/script');
const injected = `<script>window.NOVA_PIECES=${JSON.stringify(pieceMap)};window.NOVA_GAS_POLL_MS=25;</script>`
  + `<script>${escapeScript(client)}</script>`
  + `<script>${escapeScript(app)}</script>`;
html = html.replace('</body>', `${injected}</body>`);

const output = server.replace('__EMBEDDED_HTML__', JSON.stringify(html));
fs.writeFileSync(path.join(root, 'gas/Code.gs'), output);
console.log(`Generated gas/Code.gs (${Buffer.byteLength(output)} bytes, UrlFetchApp calls: ${(output.match(/UrlFetchApp/g) || []).length})`);
