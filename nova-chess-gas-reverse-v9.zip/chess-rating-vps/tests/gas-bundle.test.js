const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('generated Apps Script bundle is self-contained and has no outbound fetch', () => {
  const code = fs.readFileSync(path.join(__dirname, '..', 'gas', 'Code.gs'), 'utf8');
  assert.ok(code.length > 150_000, 'UI, CSS and pieces should be embedded');
  assert.equal(code.includes('UrlFetchApp'), false);
  assert.equal(code.includes('trycloudflare.com'), false);
  assert.equal(code.includes('VPS_URL'), false);
  assert.match(code, /function bridgeRequest\(/);
  assert.match(code, /function doPost\(/);
  assert.match(code, /data:image\/svg\+xml;base64/);
});
