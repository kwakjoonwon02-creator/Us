/*
 * NOVA CHESS reverse Apps Script bridge.
 *
 * Browser -> google.script.run -> Apps Script queue
 * VPS     -> Apps Script doPost pull/push (outbound connection from the VPS)
 *
 * Apps Script outbound HTTP calls are intentionally not used.
 */
const REVERSE_SECRET = 'CHANGE_TO_THE_SAME_LONG_RANDOM_SECRET';
const REQUEST_INDEX_KEY = 'nova:reverse:request-index:v1';
const REQUEST_PREFIX = 'nova:reverse:request:';
const RESPONSE_PREFIX = 'nova:reverse:response:';
const REQUEST_TTL_MS = 60000;
const RESPONSE_TTL_SECONDS = 90;
const BRIDGE_WAIT_MS = 45000;
const WORKER_WAIT_MS = 20000;
const MAX_QUEUE_DEPTH = 50;
const EMBEDDED_HTML = __EMBEDDED_HTML__;

function doGet() {
  assertReverseConfig_();
  return HtmlService.createHtmlOutput(EMBEDDED_HTML)
    .setTitle('NOVA CHESS')
    .addMetaTag('viewport', 'width=device-width,initial-scale=1,viewport-fit=cover');
}

function doPost(event) {
  try {
    const body = JSON.parse(event && event.postData && event.postData.contents || '{}');
    if (!safeEqual_(String(body.secret || ''), REVERSE_SECRET)) {
      return jsonOutput_({ ok: false, code: 'REVERSE_AUTH_FAILED', message: '역방향 브리지 인증 실패' });
    }
    if (body.op === 'pull') {
      return jsonOutput_({ ok: true, requests: waitAndPullRequests_() });
    }
    if (body.op === 'push') {
      const accepted = storeWorkerResults_(body.results);
      return jsonOutput_({ ok: true, accepted: accepted });
    }
    return jsonOutput_({ ok: false, code: 'UNKNOWN_WORKER_OPERATION', message: '지원하지 않는 작업입니다.' });
  } catch (error) {
    return jsonOutput_({ ok: false, code: 'REVERSE_SERVER_ERROR', message: String(error && error.message || error) });
  }
}

function bridgeRequest(request) {
  assertReverseConfig_();
  const normalized = normalizeBrowserRequest_(request);
  const requestId = Utilities.getUuid().replace(/-/g, '');
  const queued = {
    id: requestId,
    createdAt: Date.now(),
    token: normalized.token,
    kind: normalized.kind,
    path: normalized.path,
    method: normalized.method,
    eventName: normalized.eventName,
    body: normalized.body,
  };

  enqueueRequest_(queued);
  const cache = CacheService.getScriptCache();
  const responseKey = RESPONSE_PREFIX + requestId;
  const deadline = Date.now() + BRIDGE_WAIT_MS;
  while (Date.now() < deadline) {
    const value = cache.get(responseKey);
    if (value !== null) {
      cache.remove(responseKey);
      return JSON.parse(value);
    }
    Utilities.sleep(50);
  }

  removeQueuedRequest_(requestId);
  throw new Error('VPS 역방향 브리지 응답 시간이 초과되었습니다. VPS 워커와 GAS_WEB_APP_URL을 확인하세요.');
}

function normalizeBrowserRequest_(request) {
  request = request || {};
  const kind = String(request.kind || '');
  if (['api', 'state', 'action'].indexOf(kind) < 0) throw new Error('지원하지 않는 브리지 요청입니다.');
  const token = String(request.token || '').slice(0, 300);
  const normalized = { kind: kind, token: token, path: '', method: 'GET', eventName: '', body: null };

  if (kind === 'api') {
    const path = String(request.path || '');
    if (!/^\/api\/[A-Za-z0-9_?=&%./-]*$/.test(path) || path.length > 1000) throw new Error('허용되지 않는 API 경로입니다.');
    const method = String(request.method || 'GET').toUpperCase();
    if (['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].indexOf(method) < 0) throw new Error('허용되지 않는 HTTP 메서드입니다.');
    normalized.path = path;
    normalized.method = method;
    normalized.body = request.body === undefined ? null : request.body;
  } else if (kind === 'state') {
    normalized.body = { lastGameId: String(request.lastGameId || '').slice(0, 64) };
  } else {
    normalized.eventName = String(request.eventName || '').slice(0, 64);
    if (!/^[a-z]+(?::[a-z-]+)+$/.test(normalized.eventName)) throw new Error('허용되지 않는 이벤트입니다.');
    normalized.body = request.body || {};
  }

  const encoded = JSON.stringify(normalized);
  if (encoded.length > 7500) throw new Error('요청이 너무 큽니다.');
  return normalized;
}

function enqueueRequest_(request) {
  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  try {
    const properties = PropertiesService.getScriptProperties();
    const index = readIndex_(properties).filter(function (item) {
      return item && item.id && Number(item.createdAt || 0) > Date.now() - REQUEST_TTL_MS;
    });
    if (index.length >= MAX_QUEUE_DEPTH) throw new Error('브리지 요청이 너무 많습니다. 잠시 후 다시 시도하세요.');
    properties.setProperty(REQUEST_PREFIX + request.id, JSON.stringify(request));
    index.push({ id: request.id, createdAt: request.createdAt });
    properties.setProperty(REQUEST_INDEX_KEY, JSON.stringify(index));
  } finally {
    lock.releaseLock();
  }
}

function waitAndPullRequests_() {
  const deadline = Date.now() + WORKER_WAIT_MS;
  while (Date.now() < deadline) {
    const requests = pullRequests_(40);
    if (requests.length) return requests;
    Utilities.sleep(100);
  }
  return [];
}

function pullRequests_(limit) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) return [];
  try {
    const properties = PropertiesService.getScriptProperties();
    const timestamp = Date.now();
    const index = readIndex_(properties);
    const valid = index.filter(function (item) {
      return item && item.id && Number(item.createdAt || 0) > timestamp - REQUEST_TTL_MS;
    });
    const taken = valid.slice(0, limit);
    const remaining = valid.slice(taken.length);
    properties.setProperty(REQUEST_INDEX_KEY, JSON.stringify(remaining));
    const requests = [];
    taken.forEach(function (item) {
      const key = REQUEST_PREFIX + item.id;
      const value = properties.getProperty(key);
      properties.deleteProperty(key);
      if (value) {
        try { requests.push(JSON.parse(value)); } catch (_) {}
      }
    });
    return requests;
  } finally {
    lock.releaseLock();
  }
}

function removeQueuedRequest_(requestId) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) return;
  try {
    const properties = PropertiesService.getScriptProperties();
    const index = readIndex_(properties).filter(function (item) { return item.id !== requestId; });
    properties.setProperty(REQUEST_INDEX_KEY, JSON.stringify(index));
    properties.deleteProperty(REQUEST_PREFIX + requestId);
  } finally {
    lock.releaseLock();
  }
}

function storeWorkerResults_(results) {
  const cache = CacheService.getScriptCache();
  let accepted = 0;
  (Array.isArray(results) ? results : []).slice(0, 50).forEach(function (item) {
    const id = String(item && item.id || '');
    if (!/^[a-f0-9]{32}$/i.test(id)) return;
    const value = JSON.stringify(item.result || { ok: false, status: 502, data: { ok: false, message: '잘못된 VPS 응답' } });
    if (value.length > 95000) return;
    cache.put(RESPONSE_PREFIX + id, value, RESPONSE_TTL_SECONDS);
    accepted += 1;
  });
  return accepted;
}

function readIndex_(properties) {
  try {
    const value = JSON.parse(properties.getProperty(REQUEST_INDEX_KEY) || '[]');
    return Array.isArray(value) ? value : [];
  } catch (_) {
    return [];
  }
}

function safeEqual_(a, b) {
  a = String(a || '');
  b = String(b || '');
  if (a.length !== b.length) return false;
  let result = 0;
  for (let index = 0; index < a.length; index += 1) result |= a.charCodeAt(index) ^ b.charCodeAt(index);
  return result === 0;
}

function assertReverseConfig_() {
  if (!REVERSE_SECRET || REVERSE_SECRET.length < 24 || /^CHANGE_/.test(REVERSE_SECRET)) {
    throw new Error('REVERSE_SECRET에 VPS GAS_BRIDGE_SECRET과 같은 24자 이상의 비밀 키를 입력하세요.');
  }
}

function jsonOutput_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
