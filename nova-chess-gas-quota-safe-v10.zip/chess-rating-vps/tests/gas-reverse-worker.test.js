const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createGasReverseWorker, extractSessionToken } = require('../src/gas-reverse-worker');

function listen(server) {
  return new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
}

function close(server) {
  return new Promise((resolve) => server.close(resolve));
}

function jsonBody(request) {
  return new Promise((resolve, reject) => {
    let value = '';
    request.setEncoding('utf8');
    request.on('data', (chunk) => { value += chunk; });
    request.on('end', () => {
      try { resolve(JSON.parse(value || '{}')); } catch (error) { reject(error); }
    });
    request.on('error', reject);
  });
}

test('reverse worker pulls from Apps Script and returns a local VPS response', async (t) => {
  const localServer = http.createServer((request, response) => {
    assert.equal(request.url, '/api/bootstrap');
    response.setHeader('Content-Type', 'application/json');
    response.setHeader('Set-Cookie', 'nova_chess_session=new-session-token; Path=/; HttpOnly');
    response.end(JSON.stringify({ ok: true, me: { handle: 'reverse_player' } }));
  });
  await listen(localServer);

  let delivered = false;
  let resolveResult;
  const resultPromise = new Promise((resolve) => { resolveResult = resolve; });
  const gasServer = http.createServer(async (request, response) => {
    const body = await jsonBody(request);
    assert.equal(body.secret, 'reverse-secret-12345678901234567890');
    response.setHeader('Content-Type', 'application/json');
    if (body.op === 'pull') {
      if (!delivered) {
        delivered = true;
        response.end(JSON.stringify({
          ok: true,
          requests: [{ id: '0123456789abcdef0123456789abcdef', kind: 'api', path: '/api/bootstrap', method: 'GET', token: '' }],
        }));
      } else {
        setTimeout(() => response.end(JSON.stringify({ ok: true, requests: [] })), 25);
      }
      return;
    }
    if (body.op === 'push') {
      resolveResult(body.results[0]);
      response.end(JSON.stringify({ ok: true, accepted: body.results.length }));
      return;
    }
    response.end(JSON.stringify({ ok: false, message: 'unknown operation' }));
  });
  await listen(gasServer);

  const config = {
    port: localServer.address().port,
    gasReverseUrl: `http://127.0.0.1:${gasServer.address().port}/exec`,
    gasReverseSecret: 'reverse-secret-12345678901234567890',
    gasBridgeSecret: 'local-bridge-secret',
  };
  const logger = { log() {}, error() {} };
  const worker = createGasReverseWorker({ config, logger });
  worker.start();

  t.after(async () => {
    await worker.stop();
    await Promise.all([close(localServer), close(gasServer)]);
  });

  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error('reverse result timeout')), 3000);
  });
  const result = await Promise.race([resultPromise, timeout]);
  clearTimeout(timeoutId);
  assert.equal(result.id, '0123456789abcdef0123456789abcdef');
  assert.equal(result.result.ok, true);
  assert.equal(result.result.data.me.handle, 'reverse_player');
  assert.equal(result.result.bridgeToken, 'new-session-token');
});

test('session cookie extraction handles set and clear', () => {
  assert.equal(extractSessionToken('nova_chess_session=abc123; Path=/'), 'abc123');
  assert.equal(extractSessionToken('nova_chess_session=; Max-Age=0; Path=/'), '');
  assert.equal(extractSessionToken('other=value; Path=/'), null);
});
