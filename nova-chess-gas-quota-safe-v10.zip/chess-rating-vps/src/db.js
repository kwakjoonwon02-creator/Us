const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { now } = require('./utils');

function createDatabase(config) {
  fs.mkdirSync(config.dataDir, { recursive: true });
  const filename = path.join(config.dataDir, 'chess.db');
  const db = new DatabaseSync(filename);

  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec('PRAGMA synchronous = NORMAL;');

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      handle TEXT NOT NULL,
      handle_key TEXT NOT NULL UNIQUE,
      email TEXT,
      email_key TEXT UNIQUE,
      password_hash TEXT,
      is_guest INTEGER NOT NULL DEFAULT 1 CHECK (is_guest IN (0, 1)),
      rating INTEGER NOT NULL DEFAULT ${Number(config.initialRating)},
      games_played INTEGER NOT NULL DEFAULT 0,
      rated_games INTEGER NOT NULL DEFAULT 0,
      wins INTEGER NOT NULL DEFAULT 0,
      draws INTEGER NOT NULL DEFAULT 0,
      losses INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      last_seen_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS sessions_user_id_idx ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS sessions_expires_at_idx ON sessions(expires_at);

    CREATE TABLE IF NOT EXISTS games (
      id TEXT PRIMARY KEY,
      mode TEXT NOT NULL CHECK (mode IN ('quick', 'invite')),
      rated INTEGER NOT NULL DEFAULT 1 CHECK (rated IN (0, 1)),
      white_user_id INTEGER NOT NULL REFERENCES users(id),
      black_user_id INTEGER NOT NULL REFERENCES users(id),
      status TEXT NOT NULL CHECK (status IN ('active', 'finished', 'aborted')),
      fen TEXT NOT NULL,
      pgn TEXT NOT NULL DEFAULT '',
      turn TEXT NOT NULL CHECK (turn IN ('w', 'b')),
      white_clock_ms INTEGER NOT NULL,
      black_clock_ms INTEGER NOT NULL,
      last_clock_at INTEGER NOT NULL,
      result TEXT,
      winner_user_id INTEGER REFERENCES users(id),
      reason TEXT,
      white_rating_before INTEGER NOT NULL,
      black_rating_before INTEGER NOT NULL,
      white_rating_after INTEGER,
      black_rating_after INTEGER,
      white_rating_delta INTEGER,
      black_rating_delta INTEGER,
      created_at INTEGER NOT NULL,
      finished_at INTEGER
    );

    CREATE INDEX IF NOT EXISTS games_white_user_idx ON games(white_user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS games_black_user_idx ON games(black_user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS games_status_idx ON games(status);

    CREATE TABLE IF NOT EXISTS rating_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
      rating_before INTEGER NOT NULL,
      rating_after INTEGER NOT NULL,
      delta INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS rating_history_user_idx ON rating_history(user_id, created_at DESC);
  `);

  db.exec(`
    UPDATE games
    SET rated = 0
    WHERE status = 'active'
      AND rated = 1
      AND (
        (SELECT password_hash FROM users WHERE id = games.white_user_id) IS NULL
        OR (SELECT password_hash FROM users WHERE id = games.black_user_id) IS NULL
      );
  `);

  const statements = {
    createUser: db.prepare(`
      INSERT INTO users (handle, handle_key, email, email_key, password_hash, is_guest, rating, created_at, last_seen_at)
      VALUES (@handle, @handleKey, @email, @emailKey, @passwordHash, @isGuest, @rating, @createdAt, @lastSeenAt)
    `),
    getUserById: db.prepare('SELECT * FROM users WHERE id = ?'),
    getUserByHandleKey: db.prepare('SELECT * FROM users WHERE handle_key = ?'),
    getUserByEmailKey: db.prepare('SELECT * FROM users WHERE email_key = ?'),
    touchUser: db.prepare('UPDATE users SET last_seen_at = ? WHERE id = ?'),
    createSession: db.prepare(`
      INSERT INTO sessions (token_hash, user_id, created_at, expires_at)
      VALUES (?, ?, ?, ?)
    `),
    getSessionUser: db.prepare(`
      SELECT u.*
      FROM sessions s
      JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ? AND s.expires_at > ?
    `),
    deleteSession: db.prepare('DELETE FROM sessions WHERE token_hash = ?'),
    deleteUserSessions: db.prepare('DELETE FROM sessions WHERE user_id = ?'),
    cleanupSessions: db.prepare('DELETE FROM sessions WHERE expires_at <= ?'),
    cleanupUnusedGuests: db.prepare(`
      DELETE FROM users
      WHERE is_guest = 1
        AND games_played = 0
        AND last_seen_at <= ?
        AND NOT EXISTS (SELECT 1 FROM sessions WHERE sessions.user_id = users.id)
    `),
    registerAccount: db.prepare(`
      UPDATE users
      SET handle = @handle,
          handle_key = @handleKey,
          email = @email,
          email_key = @emailKey,
          password_hash = @passwordHash,
          is_guest = 0,
          last_seen_at = @lastSeenAt
      WHERE id = @id AND password_hash IS NULL
    `),
    leaderboard: db.prepare(`
      SELECT id, handle, is_guest, password_hash, rating, games_played, rated_games, wins, draws, losses, created_at
      FROM users
      WHERE is_guest = 0 AND password_hash IS NOT NULL
      ORDER BY rating DESC, rated_games DESC, created_at ASC
      LIMIT ?
    `),
    recentGames: db.prepare(`
      SELECT
        g.*,
        wu.handle AS white_handle,
        bu.handle AS black_handle
      FROM games g
      JOIN users wu ON wu.id = g.white_user_id
      JOIN users bu ON bu.id = g.black_user_id
      WHERE (g.white_user_id = ? OR g.black_user_id = ?) AND g.status = 'finished'
      ORDER BY g.finished_at DESC
      LIMIT ?
    `),
    createGame: db.prepare(`
      INSERT INTO games (
        id, mode, rated, white_user_id, black_user_id, status, fen, pgn, turn,
        white_clock_ms, black_clock_ms, last_clock_at,
        white_rating_before, black_rating_before, created_at
      ) VALUES (
        @id, @mode, @rated, @whiteUserId, @blackUserId, 'active', @fen, @pgn, @turn,
        @whiteClockMs, @blackClockMs, @lastClockAt,
        @whiteRatingBefore, @blackRatingBefore, @createdAt
      )
    `),
    updateGame: db.prepare(`
      UPDATE games
      SET fen = @fen,
          pgn = @pgn,
          turn = @turn,
          white_clock_ms = @whiteClockMs,
          black_clock_ms = @blackClockMs,
          last_clock_at = @lastClockAt
      WHERE id = @id AND status = 'active'
    `),
    getGame: db.prepare(`
      SELECT
        g.*,
        wu.handle AS white_handle,
        wu.rating AS white_current_rating,
        bu.handle AS black_handle,
        bu.rating AS black_current_rating
      FROM games g
      JOIN users wu ON wu.id = g.white_user_id
      JOIN users bu ON bu.id = g.black_user_id
      WHERE g.id = ?
    `),
    activeGameForUser: db.prepare(`
      SELECT id FROM games
      WHERE status = 'active' AND (white_user_id = ? OR black_user_id = ?)
      ORDER BY created_at DESC LIMIT 1
    `),
    listActiveGames: db.prepare(`
      SELECT * FROM games WHERE status = 'active' ORDER BY created_at ASC
    `),
    updateRatedWinner: db.prepare(`
      UPDATE users
      SET rating = @rating,
          games_played = games_played + 1,
          rated_games = rated_games + 1,
          wins = wins + @win,
          draws = draws + @draw,
          losses = losses + @loss,
          last_seen_at = @lastSeenAt
      WHERE id = @id
    `),
    updateUnratedWinner: db.prepare(`
      UPDATE users
      SET games_played = games_played + 1,
          wins = wins + @win,
          draws = draws + @draw,
          losses = losses + @loss,
          last_seen_at = @lastSeenAt
      WHERE id = @id
    `),
    finishGame: db.prepare(`
      UPDATE games
      SET status = 'finished',
          fen = @fen,
          pgn = @pgn,
          turn = @turn,
          white_clock_ms = @whiteClockMs,
          black_clock_ms = @blackClockMs,
          last_clock_at = @lastClockAt,
          result = @result,
          winner_user_id = @winnerUserId,
          reason = @reason,
          white_rating_after = @whiteRatingAfter,
          black_rating_after = @blackRatingAfter,
          white_rating_delta = @whiteRatingDelta,
          black_rating_delta = @blackRatingDelta,
          finished_at = @finishedAt
      WHERE id = @id AND status = 'active'
    `),
    addRatingHistory: db.prepare(`
      INSERT INTO rating_history (user_id, game_id, rating_before, rating_after, delta, created_at)
      VALUES (@userId, @gameId, @ratingBefore, @ratingAfter, @delta, @createdAt)
    `),
    abortGame: db.prepare(`
      UPDATE games SET status = 'aborted', reason = ?, finished_at = ?
      WHERE id = ? AND status = 'active'
    `),
  };

  function publicUser(row) {
    if (!row) return null;
    return {
      id: row.id,
      handle: row.handle,
      isGuest: Boolean(row.is_guest),
      isAccount: !row.is_guest && Boolean(row.password_hash),
      ratedEligible: !row.is_guest && Boolean(row.password_hash),
      rating: row.rating,
      gamesPlayed: row.games_played,
      ratedGames: row.rated_games,
      wins: row.wins,
      draws: row.draws,
      losses: row.losses,
      createdAt: row.created_at,
    };
  }

  function createGuest(handle) {
    const timestamp = now();
    const info = statements.createUser.run({
      handle,
      handleKey: handle.toLocaleLowerCase('en-US'),
      email: null,
      emailKey: null,
      passwordHash: null,
      isGuest: 1,
      rating: config.initialRating,
      createdAt: timestamp,
      lastSeenAt: timestamp,
    });
    return statements.getUserById.get(info.lastInsertRowid);
  }

  function createSession(tokenHash, userId, expiresAt) {
    const timestamp = now();
    statements.createSession.run(tokenHash, userId, timestamp, expiresAt);
  }

  function recentGames(userId, limit = 8) {
    return statements.recentGames.all(userId, userId, limit).map((row) => {
      const userWasWhite = row.white_user_id === userId;
      const opponent = userWasWhite ? row.black_handle : row.white_handle;
      const delta = userWasWhite ? row.white_rating_delta : row.black_rating_delta;
      const before = userWasWhite ? row.white_rating_before : row.black_rating_before;
      const after = userWasWhite ? row.white_rating_after : row.black_rating_after;
      let outcome = 'draw';
      if (row.winner_user_id === userId) outcome = 'win';
      else if (row.winner_user_id !== null) outcome = 'loss';

      return {
        id: row.id,
        opponent,
        color: userWasWhite ? 'white' : 'black',
        outcome,
        result: row.result,
        reason: row.reason,
        rated: Boolean(row.rated),
        ratingBefore: before,
        ratingAfter: after,
        ratingDelta: delta,
        finishedAt: row.finished_at,
      };
    });
  }

  function finishTransaction(payload) {
    const timestamp = payload.finishedAt;
    db.exec('BEGIN IMMEDIATE;');
    try {
      const whiteStats = {
        id: payload.whiteUserId,
        win: payload.winnerUserId === payload.whiteUserId ? 1 : 0,
        draw: payload.winnerUserId === null ? 1 : 0,
        loss: payload.winnerUserId === payload.blackUserId ? 1 : 0,
        lastSeenAt: timestamp,
      };
      const blackStats = {
        id: payload.blackUserId,
        win: payload.winnerUserId === payload.blackUserId ? 1 : 0,
        draw: payload.winnerUserId === null ? 1 : 0,
        loss: payload.winnerUserId === payload.whiteUserId ? 1 : 0,
        lastSeenAt: timestamp,
      };

      if (payload.rated) {
        statements.updateRatedWinner.run({ ...whiteStats, rating: payload.whiteRatingAfter });
        statements.updateRatedWinner.run({ ...blackStats, rating: payload.blackRatingAfter });
      } else {
        statements.updateUnratedWinner.run(whiteStats);
        statements.updateUnratedWinner.run(blackStats);
      }

      const finishParams = {
        id: payload.id,
        fen: payload.fen,
        pgn: payload.pgn,
        turn: payload.turn,
        whiteClockMs: payload.whiteClockMs,
        blackClockMs: payload.blackClockMs,
        lastClockAt: payload.lastClockAt,
        result: payload.result,
        winnerUserId: payload.winnerUserId,
        reason: payload.reason,
        whiteRatingAfter: payload.whiteRatingAfter,
        blackRatingAfter: payload.blackRatingAfter,
        whiteRatingDelta: payload.whiteRatingDelta,
        blackRatingDelta: payload.blackRatingDelta,
        finishedAt: payload.finishedAt,
      };
      const result = statements.finishGame.run(finishParams);
      if (result.changes !== 1) throw new Error('Game was already finished');

      if (payload.rated) {
        statements.addRatingHistory.run({
          userId: payload.whiteUserId,
          gameId: payload.id,
          ratingBefore: payload.whiteRatingBefore,
          ratingAfter: payload.whiteRatingAfter,
          delta: payload.whiteRatingDelta,
          createdAt: timestamp,
        });
        statements.addRatingHistory.run({
          userId: payload.blackUserId,
          gameId: payload.id,
          ratingBefore: payload.blackRatingBefore,
          ratingAfter: payload.blackRatingAfter,
          delta: payload.blackRatingDelta,
          createdAt: timestamp,
        });
      }
      db.exec('COMMIT;');
    } catch (error) {
      db.exec('ROLLBACK;');
      throw error;
    }
  }

  return {
    raw: db,
    filename,
    publicUser,
    createGuest,
    createSession,
    getUserById: (id) => statements.getUserById.get(id),
    getUserByHandleKey: (key) => statements.getUserByHandleKey.get(key),
    getUserByEmailKey: (key) => statements.getUserByEmailKey.get(key),
    getUserBySessionHash: (hash) => statements.getSessionUser.get(hash, now()),
    touchUser: (id) => statements.touchUser.run(now(), id),
    deleteSession: (hash) => statements.deleteSession.run(hash),
    deleteUserSessions: (id) => statements.deleteUserSessions.run(id),
    cleanupSessions: () => statements.cleanupSessions.run(now()),
    cleanupUnusedGuests: (olderThan) => statements.cleanupUnusedGuests.run(olderThan),
    registerAccount: (payload) => statements.registerAccount.run(payload),
    leaderboard: (limit = 20) => statements.leaderboard.all(limit).map(publicUser),
    recentGames,
    createGame: (payload) => statements.createGame.run(payload),
    updateGame: (payload) => statements.updateGame.run(payload),
    getGame: (id) => statements.getGame.get(id),
    activeGameForUser: (id) => statements.activeGameForUser.get(id, id),
    listActiveGames: () => statements.listActiveGames.all(),
    finishGame: finishTransaction,
    abortGame: (id, reason) => statements.abortGame.run(reason, now(), id),
    close: () => db.close(),
  };
}

module.exports = { createDatabase };
