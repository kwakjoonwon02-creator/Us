function expectedScore(rating, opponentRating) {
  return 1 / (1 + 10 ** ((opponentRating - rating) / 400));
}

function calculateElo(ratingA, ratingB, scoreA, { k = 32, floor = 0 } = {}) {
  if (![0, 0.5, 1].includes(scoreA)) {
    throw new TypeError('scoreA must be 0, 0.5, or 1');
  }

  // With the same K-factor, Elo is zero-sum before a configured rating floor.
  const rawDeltaA = Math.round(k * (scoreA - expectedScore(ratingA, ratingB)));
  const rawDeltaB = -rawDeltaA;
  const nextRatingA = Math.max(floor, ratingA + rawDeltaA);
  const nextRatingB = Math.max(floor, ratingB + rawDeltaB);

  return {
    ratingA: nextRatingA,
    ratingB: nextRatingB,
    deltaA: nextRatingA - ratingA,
    deltaB: nextRatingB - ratingB,
  };
}

module.exports = { expectedScore, calculateElo };
