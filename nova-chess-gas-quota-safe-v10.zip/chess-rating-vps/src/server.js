process.umask(0o077);

const { config } = require('./config');
const { buildApplication } = require('./app');
const { createGasReverseWorker } = require('./gas-reverse-worker');

const application = buildApplication(config);
const reverseWorker = createGasReverseWorker({ config });

application.server.listen(config.port, config.host, () => {
  console.log(`NOVA CHESS listening on http://${config.host}:${config.port}`);
  console.log(`SQLite database: ${application.db.filename}`);
  reverseWorker?.start();
});

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`Received ${signal}; shutting down...`);
  try {
    await reverseWorker?.stop();
    await application.close();
    process.exit(0);
  } catch (error) {
    console.error('Shutdown failed:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
  shutdown('uncaughtException');
});
process.on('unhandledRejection', (error) => {
  console.error('Unhandled rejection:', error);
});
