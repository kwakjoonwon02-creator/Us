const crypto = require('node:crypto');

function now() {
  return Date.now();
}

function randomId(bytes = 16) {
  return crypto.randomBytes(bytes).toString('base64url');
}

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function parseCookies(header = '') {
  const cookies = {};
  for (const chunk of header.split(';')) {
    const index = chunk.indexOf('=');
    if (index < 1) continue;
    const key = chunk.slice(0, index).trim();
    const value = chunk.slice(index + 1).trim();
    try {
      cookies[key] = decodeURIComponent(value);
    } catch {
      cookies[key] = value;
    }
  }
  return cookies;
}

function safeJson(value) {
  return JSON.stringify(value).replace(/[<>&]/g, (character) => ({
    '<': '\\u003c',
    '>': '\\u003e',
    '&': '\\u0026',
  })[character]);
}

function cleanText(value, max = 100) {
  return String(value ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
}

module.exports = { now, randomId, sha256, parseCookies, safeJson, cleanText };
