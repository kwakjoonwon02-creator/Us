const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { randomId, sha256, parseCookies, now, cleanText } = require('./utils');

const scrypt = promisify(crypto.scrypt);
const SESSION_COOKIE = 'nova_chess_session';
const HANDLE_PATTERN = /^[\p{L}\p{N}_-]{3,20}$/u;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/u;

class AuthError extends Error {
  constructor(message, code = 'AUTH_ERROR', status = 400) {
    super(message);
    this.name = 'AuthError';
    this.code = code;
    this.status = status;
  }
}

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, 64, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 64 * 1024 * 1024,
  });
  return `scrypt$16384$8$1$${salt.toString('base64url')}$${Buffer.from(key).toString('base64url')}`;
}

async function verifyPassword(password, stored) {
  try {
    const [algorithm, nRaw, rRaw, pRaw, saltRaw, hashRaw] = String(stored || '').split('$');
    if (algorithm !== 'scrypt') return false;
    const expected = Buffer.from(hashRaw, 'base64url');
    const actual = await scrypt(password, Buffer.from(saltRaw, 'base64url'), expected.length, {
      N: Number(nRaw),
      r: Number(rRaw),
      p: Number(pRaw),
      maxmem: 64 * 1024 * 1024,
    });
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

function normalizeHandle(value) {
  const handle = cleanText(value, 20);
  if (!HANDLE_PATTERN.test(handle)) {
    throw new AuthError('아이디는 3~20자의 한글·영문·숫자·_·-만 사용할 수 있습니다.', 'INVALID_HANDLE');
  }
  return { handle, key: handle.toLocaleLowerCase('en-US') };
}

function normalizeEmail(value) {
  const email = cleanText(value, 120).toLocaleLowerCase('en-US');
  if (!EMAIL_PATTERN.test(email)) {
    throw new AuthError('올바른 이메일 주소를 입력해 주세요.', 'INVALID_EMAIL');
  }
  return { email, key: email };
}

function validatePassword(value) {
  const password = String(value ?? '');
  if (password.length < 8 || password.length > 128) {
    throw new AuthError('비밀번호는 8~128자로 입력해 주세요.', 'INVALID_PASSWORD');
  }
  return password;
}

function createAuth({ db, config }) {
  const sessionMs = config.sessionDays * 24 * 60 * 60 * 1000;

  function cookieValue(token, { clear = false } = {}) {
    const pieces = [
      `${SESSION_COOKIE}=${clear ? '' : encodeURIComponent(token)}`,
      'Path=/',
      'HttpOnly',
      config.cookieSecure ? 'SameSite=None' : 'SameSite=Lax',
      clear ? 'Max-Age=0' : `Max-Age=${Math.floor(sessionMs / 1000)}`,
    ];
    if (config.cookieSecure) pieces.push('Secure', 'Partitioned');
    return pieces.join('; ');
  }

  function sessionFromCookieHeader(header) {
    const token = parseCookies(header)[SESSION_COOKIE];
    if (!token || token.length < 20 || token.length > 200) return null;
    const tokenHash = sha256(token);
    const user = db.getUserBySessionHash(tokenHash);
    if (!user) return null;
    return { token, tokenHash, user };
  }

  function issueSession(userId) {
    const token = randomId(32);
    const tokenHash = sha256(token);
    db.createSession(tokenHash, userId, now() + sessionMs);
    return { token, tokenHash, cookie: cookieValue(token) };
  }

  function uniqueGuestHandle() {
    for (let attempt = 0; attempt < 12; attempt += 1) {
      const suffix = crypto.randomBytes(3).toString('hex').slice(0, 5).toUpperCase();
      const handle = `Guest-${suffix}`;
      if (!db.getUserByHandleKey(handle.toLocaleLowerCase('en-US'))) return handle;
    }
    return `Guest-${Date.now().toString(36).toUpperCase()}`;
  }

  function createGuestSession() {
    const user = db.createGuest(uniqueGuestHandle());
    const session = issueSession(user.id);
    return { user, session };
  }

  function getRequestSession(req) {
    return sessionFromCookieHeader(req.headers.cookie || '');
  }

  function ensureIdentity(req, res, next) {
    try {
      let session = getRequestSession(req);
      if (!session) {
        const created = createGuestSession();
        res.setHeader('Set-Cookie', created.session.cookie);
        session = {
          token: created.session.token,
          tokenHash: created.session.tokenHash,
          user: created.user,
        };
      } else if (now() - session.user.last_seen_at > 60_000) {
        db.touchUser(session.user.id);
      }
      req.auth = session;
      next();
    } catch (error) {
      next(error);
    }
  }

  async function register(user, currentTokenHash, input) {
    if (user.password_hash) {
      throw new AuthError('이미 가입된 계정입니다.', 'ALREADY_REGISTERED', 409);
    }

    const { handle, key: handleKey } = normalizeHandle(input.handle);
    const { email, key: emailKey } = normalizeEmail(input.email);
    const password = validatePassword(input.password);

    const existingHandle = db.getUserByHandleKey(handleKey);
    if (existingHandle && existingHandle.id !== user.id) {
      throw new AuthError('이미 사용 중인 아이디입니다.', 'HANDLE_TAKEN', 409);
    }
    const existingEmail = db.getUserByEmailKey(emailKey);
    if (existingEmail && existingEmail.id !== user.id) {
      throw new AuthError('이미 사용 중인 이메일입니다.', 'EMAIL_TAKEN', 409);
    }

    const passwordHash = await hashPassword(password);
    try {
      const result = db.registerAccount({
        id: user.id,
        handle,
        handleKey,
        email,
        emailKey,
        passwordHash,
        lastSeenAt: now(),
      });
      if (result.changes !== 1) {
        throw new AuthError('가입 상태가 변경되었습니다. 새로고침 후 다시 시도해 주세요.', 'REGISTER_CONFLICT', 409);
      }
    } catch (error) {
      if (String(error.code || '').startsWith('SQLITE_CONSTRAINT')) {
        throw new AuthError('아이디 또는 이메일이 이미 사용 중입니다.', 'ACCOUNT_TAKEN', 409);
      }
      throw error;
    }

    db.deleteSession(currentTokenHash);
    const session = issueSession(user.id);
    return { user: db.getUserById(user.id), session };
  }

  async function login(input) {
    const identity = cleanText(input.identity, 120).toLocaleLowerCase('en-US');
    const password = validatePassword(input.password);
    const user = identity.includes('@')
      ? db.getUserByEmailKey(identity)
      : db.getUserByHandleKey(identity);

    if (!user || !user.password_hash || !(await verifyPassword(password, user.password_hash))) {
      throw new AuthError('아이디/이메일 또는 비밀번호가 맞지 않습니다.', 'INVALID_CREDENTIALS', 401);
    }

    const session = issueSession(user.id);
    return { user, session };
  }

  function logout(tokenHash) {
    if (tokenHash) db.deleteSession(tokenHash);
    return cookieValue('', { clear: true });
  }

  return {
    SESSION_COOKIE,
    ensureIdentity,
    getRequestSession,
    sessionFromCookieHeader,
    register,
    login,
    logout,
    publicUser: db.publicUser,
  };
}

module.exports = { createAuth, AuthError, hashPassword, verifyPassword };
