#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-$ROOT_DIR/backups}"
VOLUME_NAME="${VOLUME_NAME:-nova_chess_data}"
STAMP="$(date +%Y%m%d-%H%M%S)"
ARCHIVE="nova-chess-$STAMP.tar.gz"

mkdir -p "$BACKUP_DIR"
cd "$ROOT_DIR"

WAS_RUNNING=0
CONTAINER_ID="$(docker compose ps -q app 2>/dev/null || true)"
if [[ -n "$CONTAINER_ID" ]] && [[ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER_ID" 2>/dev/null || true)" == "true" ]]; then
  WAS_RUNNING=1
fi

restart_app() {
  if [[ "$WAS_RUNNING" == "1" ]]; then
    docker compose start app >/dev/null
  fi
}
trap restart_app EXIT

if [[ "$WAS_RUNNING" == "1" ]]; then
  docker compose stop app >/dev/null
fi

docker run --rm \
  -e OUT_UID="$(id -u)" \
  -e OUT_GID="$(id -g)" \
  -v "$VOLUME_NAME:/data:ro" \
  -v "$BACKUP_DIR:/backup" \
  alpine:3.22 \
  sh -c 'tar -czf "/backup/$1" -C /data . && chown "$OUT_UID:$OUT_GID" "/backup/$1"' \
  _ "$ARCHIVE"

chmod 600 "$BACKUP_DIR/$ARCHIVE" 2>/dev/null || true
echo "백업 완료: $BACKUP_DIR/$ARCHIVE"
